package com.loyalty.prueba.lmtest.repositories;

import com.loyalty.prueba.lmtest.pojo.database.Transaccion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface TransactionRepository extends JpaRepository<Transaccion, Integer> {
    @Query(value="select * from lifebank.transaccion where (tra_date between (:startDate) and (:endDate)) and tra_ac_id= (:accountID)", nativeQuery = true)
    List<Transaccion> getTransactionsByAccount(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endStart, @Param("accountID") String accountID);
}
