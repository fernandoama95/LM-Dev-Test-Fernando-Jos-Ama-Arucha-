package com.loyalty.prueba.lmtest.pojo.database;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity(name="CLIENTE")
public class Cliente {
    @Id
    @Column(name="cli_id")
    private String clienteId;

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "ac_cli_id")
    private List<Account> accounts;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "log_cli_id")
    private List<LogRequest> logRequests;

    @Column(name="cli_name")
    private String clienteName;
    @Column(name="cli_apellido")
    private String clienteApel;
    @Column(name="cli_password")
    private String clientePass;
    @Column(name="cli_estado_cliente")
    private String clienteStatus;
    @Column(name="cli_fecha_nac")
    private LocalDateTime clienteBornDate;

    public String getClienteId() {
        return clienteId;
    }

    public void setClienteId(String clienteId) {
        this.clienteId = clienteId;
    }

    public String getClienteName() {
        return clienteName;
    }

    public void setClienteName(String clienteName) {
        this.clienteName = clienteName;
    }

    public String getClienteApel() {
        return clienteApel;
    }

    public void setClienteApel(String clienteApel) {
        this.clienteApel = clienteApel;
    }

    public String getClientePass() {
        return clientePass;
    }

    public void setClientePass(String clientePass) {
        this.clientePass = clientePass;
    }

    public LocalDateTime getClienteBornDate() {
        return clienteBornDate;
    }

    public void setClienteBornDate(LocalDateTime clienteBornDate) {
        this.clienteBornDate = clienteBornDate;
    }
}
