package com.loyalty.prueba.lmtest.process;

import com.loyalty.prueba.lmtest.pojo.database.Account;
import com.loyalty.prueba.lmtest.pojo.database.Cliente;
import com.loyalty.prueba.lmtest.pojo.payment.PaymentRequest;
import com.loyalty.prueba.lmtest.repositories.AccountRepository;
import com.loyalty.prueba.lmtest.repositories.BeneficiaryRepository;
import com.loyalty.prueba.lmtest.repositories.ClienteRepository;
import com.loyalty.prueba.lmtest.repositories.TransactionRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class PaymentProcess {
    private ClienteRepository clienteRepository;
    private BeneficiaryRepository beneficiaryRepository;
    private AccountRepository accountRepository;
    private TransactionRepository transactionRepository;


    public PaymentProcess(ClienteRepository clienteRepository, BeneficiaryRepository beneficiaryRepository, AccountRepository accountRepository, TransactionRepository transactionRepository) {
        this.clienteRepository = clienteRepository;
        this.beneficiaryRepository = beneficiaryRepository;
        this.accountRepository = accountRepository;
        this.transactionRepository = transactionRepository;
    }

    public ResponseEntity<?> process(PaymentRequest request, String idCliente, int transactionType){
        Cliente cliente =  clienteRepository.verifyCredentials(idCliente);
        PaymentService paymentService = new PaymentService(accountRepository,transactionRepository);
        if(cliente == null || request.getIdAccountPrinc().equals(request.getIdAccountDest())){//no pueden ser la misma cuenta
            return new ResponseEntity<>("Invalid client", HttpStatus.BAD_REQUEST);
        }
        Account accountPrin = accountRepository.getAccountByIDAndClient(request.getIdAccountPrinc(),idCliente);
        Account accountDest = accountRepository.verifyAccounByIDandType(request.getIdAccountDest(),transactionType);
        if(accountPrin == null || accountDest == null){
            return new ResponseEntity<>("Invalid client", HttpStatus.BAD_REQUEST);
        }
        if(request.getAmount() <=0){
            return new ResponseEntity<>("Invalid Amount", HttpStatus.CONFLICT);
        }

        if (request.getAmount() > accountPrin.getAccountTotal() || request.getAmount() > accountPrin.getAccountAvailable()
                || accountPrin.getAccountTotal() <= 0 || accountPrin.getAccountAvailable() <=0){
            return new ResponseEntity<>("",HttpStatus.CONFLICT);
        }

        if(accountPrin.getClienteId().equals(accountDest.getClienteId())){ // transferencia entre cuentas propias
            //agregar logica para tras
        }else{
            if(beneficiaryRepository.isBeneficiary(idCliente,accountDest.getAcountId()) == 0){
                return new ResponseEntity<>("Account doesn't belong to a valid Beneficiary", HttpStatus.CONFLICT);
            }
        }

        return new ResponseEntity<>("Unknown Error", HttpStatus.BAD_REQUEST);
    }
}
