package com.loyalty.prueba.lmtest.process;

import com.loyalty.prueba.lmtest.pojo.responses.JWTPojo;
import com.loyalty.prueba.lmtest.utility.JWT;
import io.jsonwebtoken.Claims;
import org.omg.CORBA.Environment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestHeader;


import javax.lang.model.util.ElementScanner6;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;

@Service("JWTHandler")
public class JWTHandler {
    private JWTPojo jwtPojo;
    private String clienteID = "";

    public String getEncrypt(String clienteId, String iNetAddress) {
        String sch = null;
        Map<String, Object> mapJWT = new HashMap<String, Object>();

        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        now = now.plusMinutes(30);

        mapJWT.put("idUser", clienteId);
        mapJWT.put("expiration-datetime", now.format(dateTimeFormatter));
        mapJWT.put("ipAddress", iNetAddress);



        JWT jwt = new JWT(mapJWT,
                "qSCFEJQMfx5kcwA9Zh3fdM9EXUSSYrSI0sKgl7XopOSyITT2mRRmQWqXd-HpNOa0K-4pbLT8qQu4m9xUF4PTDQ",
                //"jJDBnzswYhK53XQlaHJxF4fZW_UJ6WxGsZmbFM7vqiLNtJ98O6GZWo4EpADogg1wW57cZ03aUHTrd2b8T-MW1eEUT3eT4nQdUl_0KYDHBuE-TTB2KizeQlVK74EdyoE-1uDOc9KSaIzOget12JexeloRRRUXXWXJOWM_elOfePI2UcPFTAEWOBQLfZAo1TqK65V5LKR1qD3jhZeZgzIjb-n_pq8VoLe903-wgjf40T3BX8nctqmJBfic6HE0uK4h27AGLH5skCxbKZXoDPe17gyw7Q0hPMjgjvPoxA5_IWf9hECSqbunoxYP-VQ4nvZcdeqkAMP8mBDYoqrBD_vjTQ",
                "token-lifebank",
                "LM-Test",
                Long.parseLong("1800000")
        );
        sch = jwt.generate();

        return sch;
    }

    public JWTPojo decryptJWT(String sch){
        JWTPojo jwtPojo = new JWTPojo();
        try{
        //JWT jwt = new JWT("jJDBnzswYhK53XQlaHJxF4fZW_UJ6WxGsZmbFM7vqiLNtJ98O6GZWo4EpADogg1wW57cZ03aUHTrd2b8T-MW1eEUT3eT4nQdUl_0KYDHBuE-TTB2KizeQlVK74EdyoE-1uDOc9KSaIzOget12JexeloRRRUXXWXJOWM_elOfePI2UcPFTAEWOBQLfZAo1TqK65V5LKR1qD3jhZeZgzIjb-n_pq8VoLe903-wgjf40T3BX8nctqmJBfic6HE0uK4h27AGLH5skCxbKZXoDPe17gyw7Q0hPMjgjvPoxA5_IWf9hECSqbunoxYP-VQ4nvZcdeqkAMP8mBDYoqrBD_vjTQ");
            JWT jwt = new JWT("qSCFEJQMfx5kcwA9Zh3fdM9EXUSSYrSI0sKgl7XopOSyITT2mRRmQWqXd-HpNOa0K-4pbLT8qQu4m9xUF4PTDQ");
            Claims claim = jwt.extract(sch);

        String idUser = claim.get("idUser",String.class);
        String ipAdress = claim.get("ipAddress",String.class);
        String expirationDate = claim.get("expiration-datetime",String.class);
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");

        jwtPojo.setExpirationDatetime(LocalDateTime.parse(expirationDate,dateTimeFormatter));
        jwtPojo.setIpAddress(ipAdress);
        jwtPojo.setIdUser(idUser);
        }catch (Exception e){
            e.printStackTrace();
            jwtPojo = null;
        }
        return jwtPojo;
    }

    public int validateJWT(String sch, String ip){
        jwtPojo = decryptJWT(sch);
        if(jwtPojo == null){
            return 1;
        }
        LocalDateTime now  = LocalDateTime.now();
        LocalDateTime jwtTime = jwtPojo.getExpirationDatetime();
        long minutes = now.until( jwtTime, ChronoUnit.MINUTES);
        if(minutes > 30){
            return 1;
        }
        if(!ip.equals(jwtPojo.getIpAddress())){
            return 2;
        }
        clienteID = jwtPojo.getIdUser();
        return 0;
    }

    public String getClienteID() {
        return clienteID;
    }
}
