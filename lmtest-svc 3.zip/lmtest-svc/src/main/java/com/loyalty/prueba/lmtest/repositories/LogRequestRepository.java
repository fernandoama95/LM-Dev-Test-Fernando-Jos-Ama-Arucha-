package com.loyalty.prueba.lmtest.repositories;

import com.loyalty.prueba.lmtest.pojo.database.LogRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface LogRequestRepository extends JpaRepository<LogRequest,Integer> {


    @Modifying(clearAutomatically = true)
    @Query(value="insert into lifebank.logs_request(log_cli_id) values (:clienteID)",nativeQuery = true)
    @Transactional(rollbackFor = {Exception.class})
    int insertNewLogAttemp(@Param("clienteID") String clienteID);

    @Query(value="select count(log_id) from lifebank.logs_request where log_cli_id = (:clienteID)", nativeQuery = true)
    int attempNumberByClient(@Param("clienteID") String clienteID);

    @Modifying(clearAutomatically = true)
    @Query(value = "DELETE FROM lifebank.logs_request  WHERE log_cli_id = (:clienteID)", nativeQuery = true)
    @Transactional(rollbackFor = {Exception.class})
    int deleteLogAttemps(@Param("clienteID") String clienteID);
}
