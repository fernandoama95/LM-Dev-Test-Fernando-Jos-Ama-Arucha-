package com.loyalty.prueba.lmtest.parser;

import com.loyalty.prueba.lmtest.pojo.database.Account;
import com.loyalty.prueba.lmtest.pojo.responses.Accounts;
import com.loyalty.prueba.lmtest.pojo.responses.CreditCard;
import com.loyalty.prueba.lmtest.pojo.responses.Loan;
import com.loyalty.prueba.lmtest.pojo.responses.Personal;
import com.loyalty.prueba.lmtest.repositories.AccountRepository;

import java.util.ArrayList;
import java.util.List;

public class LandingParser {
    private AccountRepository accountRepository;


    public LandingParser(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;

    }

    public Accounts parser(String clientId){
        Accounts accounts = new Accounts();
        List<CreditCard> creditCards = new ArrayList<>();
        List<Loan> loans = new ArrayList<>();
        List<Personal> personals = new ArrayList<>();
        List<Account> cuentas = accountRepository.getAccountsByClient(clientId);
        for(Account account: cuentas){
            switch (account.getIdProducto()){
                case 2:
                    CreditCard creditCard =  new CreditCard();
                    creditCard.setId(account.getAcountId());
                    creditCard.setName(account.getAccountName());
                    creditCards.add(creditCard);
                    break;
                case 1:
                    Personal personal = new Personal();
                    personal.setId(account.getAcountId());
                    personal.setName(account.getAccountName());
                    personals.add(personal);
                    break;
                case 3:
                    Loan loan = new Loan();
                    loan.setId(account.getAcountId());
                    loan.setName(account.getAccountName());
                    loans.add(loan);
                    break;
            }
        }
        accounts.setLoan(loans);
        accounts.setCreditCard(creditCards);
        accounts.setPersonal(personals);
        return accounts;
    }
}
