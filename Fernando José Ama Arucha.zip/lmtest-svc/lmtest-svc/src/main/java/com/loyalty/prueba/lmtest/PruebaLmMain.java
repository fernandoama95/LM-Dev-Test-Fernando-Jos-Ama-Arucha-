package com.loyalty.prueba.lmtest;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.net.InetAddress;
@Slf4j
@SpringBootApplication
public class PruebaLmMain {

    public static void main(String[] args) {
        try{
            System.setProperty("ipAddress",InetAddress.getLocalHost().getHostAddress());
            SpringApplication.run(PruebaLmMain.class, args);
        }catch(Exception e){
            System.out.println("Ha ocurrido un error durante la encriptacion JWT: "+e);
        }

    }

}
