package com.loyalty.prueba.lmtest.controller;

import com.loyalty.prueba.lmtest.pojo.payment.PaymentRequest;
import com.loyalty.prueba.lmtest.pojo.requests.LogInRequest;
import com.loyalty.prueba.lmtest.process.VerifyProcess;
import com.loyalty.prueba.lmtest.repositories.ClienteRepository;
import com.loyalty.prueba.lmtest.repositories.LogRequestRepository;
import com.sun.deploy.util.SessionState;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/test")
public class Controller {
    @Autowired
    private Environment env;
    @Autowired
    private ClienteRepository clienteRepository;
    @Autowired
    private LogRequestRepository logRequestRepository;


    @GetMapping("/get-client-info/{idCliente}")
    public Object getClientInfo(@PathVariable int idCliente){
        //crear un pojo que contenga la informacion de todos los cliente
        System.out.println(idCliente);
        return null;

    }

    @PostMapping("/log-in")
    public ResponseEntity<?> logIn(@RequestBody LogInRequest request){
        VerifyProcess verifyProcess = new VerifyProcess(clienteRepository, logRequestRepository);
        int response = verifyProcess.process(request);
        switch(response){
            case 1://loggeo fallido
                return new ResponseEntity<>("Credenciales incorrectas", HttpStatus.UNAUTHORIZED);
            case 2://cuenta bloqueada
                return new ResponseEntity<>("User Blocked", HttpStatus.BAD_REQUEST);
            case 0://exito
                return new ResponseEntity<>("Exito", HttpStatus.OK);
            default://unexpected error
                return new ResponseEntity<>("Unknown Error", HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

    @PostMapping("/pay/credit-card")
    public Object creditCardPay(@RequestBody PaymentRequest request){ // pago de tarjeta de creditoPropia
        /*o ID de la cuenta bancaria
        o ID de la tarjeta de crédito
        o Monto a pagar*/
        return null;
    }

    @PostMapping("/transfer/{idTipoTransfer}")
    public Object transfer(@RequestBody PaymentRequest request)
    {
        /*ID de la cuenta de origen
o ID de la cuenta destino
o Monto a transferir*/
        return null;
    }

    @PostMapping("/pay/loan/")
    public Object payLoan(){  // usar la misma clase de Payment Request? de ser asi puedo agregar como identificador
        return null;
    }

    @PostMapping("/beneficiario/add")
    public Object addBeneficiario(){
        System.out.println("Prueba");
    return  null;
    }

    @PatchMapping("/beneficiario/edit")
    public Object editBeneficiario(){
        System.out.println("Prueba");
        return  null;
    }


}
