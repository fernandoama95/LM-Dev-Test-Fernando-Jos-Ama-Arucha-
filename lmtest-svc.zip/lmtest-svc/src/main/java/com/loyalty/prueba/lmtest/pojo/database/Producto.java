package com.loyalty.prueba.lmtest.pojo.database;

import javax.persistence.*;
import java.util.List;

@Entity(name="PRODUCTO")
public class Producto {
    @Id
    @Column(name="prod_id")
    private String productId;

    @Column(name="prod_tipo")
    private String tipoProducto;

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "ac_prod_id")
    private List<Account> accounts;

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getTipoProducto() {
        return tipoProducto;
    }

    public void setTipoProducto(String tipoProducto) {
        this.tipoProducto = tipoProducto;
    }
}
