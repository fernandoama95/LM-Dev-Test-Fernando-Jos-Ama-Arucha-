package com.loyalty.prueba.lmtest.pojo.responses;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "idBeneficiario",
        "idCliente",
        "idAccountBeneficiaro",
        "nombre",
        "apellido",
        "email"
})
public class BeneficiarioResponse {

    @JsonProperty("idBeneficiario")
    private String idBeneficiario;
    @JsonProperty("idCliente")
    private String idCliente;
    @JsonProperty("idAccountBeneficiaro")
    private String idAccountBeneficiaro;
    @JsonProperty("nombre")
    private String nombre;
    @JsonProperty("apellido")
    private String apellido;
    @JsonProperty("email")
    private String email;

    public BeneficiarioResponse(String idBeneficiario, String idCliente, String idAccountBeneficiaro, String nombre, String apellido, String email) {
        this.idBeneficiario = idBeneficiario;
        this.idCliente = idCliente;
        this.idAccountBeneficiaro = idAccountBeneficiaro;
        this.nombre = nombre;
        this.apellido = apellido;
        this.email = email;
    }

    @JsonProperty("idBeneficiario")
    public String getIdBeneficiario() {
        return idBeneficiario;
    }

    @JsonProperty("idBeneficiario")
    public void setIdBeneficiario(String idBeneficiario) {
        this.idBeneficiario = idBeneficiario;
    }

    @JsonProperty("idCliente")
    public String getIdCliente() {
        return idCliente;
    }

    @JsonProperty("idCliente")
    public void setIdCliente(String idCliente) {
        this.idCliente = idCliente;
    }

    @JsonProperty("idAccountBeneficiaro")
    public String getIdAccountBeneficiaro() {
        return idAccountBeneficiaro;
    }

    @JsonProperty("idAccountBeneficiaro")
    public void setIdAccountBeneficiaro(String idAccountBeneficiaro) {
        this.idAccountBeneficiaro = idAccountBeneficiaro;
    }

    @JsonProperty("nombre")
    public String getNombre() {
        return nombre;
    }

    @JsonProperty("nombre")
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @JsonProperty("apellido")
    public String getApellido() {
        return apellido;
    }

    @JsonProperty("apellido")
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    @JsonProperty("email")
    public String getEmail() {
        return email;
    }

    @JsonProperty("email")
    public void setEmail(String email) {
        this.email = email;
    }

}
