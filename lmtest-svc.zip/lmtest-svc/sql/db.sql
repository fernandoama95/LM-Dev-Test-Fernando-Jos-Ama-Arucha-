create schema prueba;
 drop table prueba.usuario;
create table prueba.usuario(
	user_id varchar(20) not null,
	user_name varchar(50) null,
	user_apellido varchar(50) null,
	user_fecha_nac timestamptz,
	user_password varchar(100),
	CONSTRAINT user_pkey PRIMARY KEY (user_id)
);

create table prueba.account(
	ac_id varchar(10) not null,
	ac_user_id varchar(20) not null,
	ac_fecha_ingreso timestamptz
);

create table prueba.credit_card(
	cc_id varchar(10) not null,
	cc_user_id varchar(20) not null,
	cc_total double,
	cc_debt double,
	cc_interes_rate double,
	cc_interes_amount double,
	cc_fecha_ingreso timestamptz
);

create table prueba.loan(
	loan_id varchar(10) not null,
	loan_user_id varchar(20) not null,
	loan_duracion int, meses
	loan_total double,
	loan_debt double,
	loan_interes double,
	loan_interes_amount double,
	loan_fecha_ingreso timestamptz
);

create table prueba.transaccion(
	tra_id serial not null,
	tra_date timestamptz,
	tra_description text,
	tra_amount double

);

SELECT COALESCE(0,1) from prueba.usuario where user_id = '05197434-1' AND user_password = 'asdf3hjkl';