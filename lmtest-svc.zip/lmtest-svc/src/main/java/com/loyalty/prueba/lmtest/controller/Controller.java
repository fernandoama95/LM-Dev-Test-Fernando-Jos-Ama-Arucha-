package com.loyalty.prueba.lmtest.controller;

import com.loyalty.prueba.lmtest.pojo.payment.PaymentRequest;
import com.loyalty.prueba.lmtest.pojo.requests.LogInRequest;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/test")
public class Controller {


    @GetMapping("/get-client-info/{idCliente}")
    public Object getClientInfo(@PathVariable int idCliente){
        //crear un pojo que contenga la informacion de todos los
        System.out.println(idCliente);
        return null;

    }

    @PostMapping("/log-in")
    public Object logIn(@RequestBody LogInRequest request){
        System.out.println(request.getUserId());
        System.out.println(request.getPassword());
        return true;
    }

    @PostMapping("/pay/credit-card")
    public Object creditCardPay(@RequestBody PaymentRequest request){ // pago de tarjeta de creditoPropia
        /*o ID de la cuenta bancaria
        o ID de la tarjeta de crédito
        o Monto a pagar*/
        return null;
    }

    @PostMapping("/transfer/{idTipoTransfer}")
    public Object transfer(@RequestBody PaymentRequest request)
    {
        /*ID de la cuenta de origen
o ID de la cuenta destino
o Monto a transferir*/
        return null;
    }

    @PostMapping("/pay/loan/")
    public Object payLoan(){  // usar la misma clase de Payment Request? de ser asi puedo agregar como identificador
        return null;
    }

    @PostMapping("/beneficiario/add")
    public Object addBeneficiario(){
        System.out.println("Prueba");
    return  null;
    }

    @PatchMapping("/beneficiario/edit")
    public Object editBeneficiario(){
        System.out.println("Prueba");
        return  null;
    }


}
