package com.loyalty.prueba.lmtest.pojo.database;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity(name="TRANSACCION")
public class Transaccion {
    /*tra_id serial not null,
	tra_ac_id varchar(10) not null,
	tra_date timestamptz,
	tra_description text,
	tra_amount numeric(5,2),*/
    @Id
    @Column(name="tra_id")
    private Integer transactionId;

    @Column(name="tra_ac_id")
    private String accountId;

    @ManyToOne(cascade = CascadeType.ALL  )
    @JoinColumn(name = "tra_ac_id", referencedColumnName = "ac_id", insertable = false, updatable = false)
    @JsonIgnore
    private Account transactionAccount;

    @Column(name="tra_date")
    private LocalDateTime transactionDate;

    @Column(name = "tra_description")
    private String transactionDesc;

    @Column(name = "tra_amount")
    private Double transactionAmount;

    public Integer getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(Integer transactionId) {
        this.transactionId = transactionId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public Account getTransactionAccount() {
        return transactionAccount;
    }

    public void setTransactionAccount(Account transactionAccount) {
        this.transactionAccount = transactionAccount;
    }

    public LocalDateTime getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(LocalDateTime transactionDate) {
        this.transactionDate = transactionDate;
    }

    public String getTransactionDesc() {
        return transactionDesc;
    }

    public void setTransactionDesc(String transactionDesc) {
        this.transactionDesc = transactionDesc;
    }

    public Double getTransactionAmount() {
        return transactionAmount;
    }

    public void setTransactionAmount(Double transactionAmount) {
        this.transactionAmount = transactionAmount;
    }
}
