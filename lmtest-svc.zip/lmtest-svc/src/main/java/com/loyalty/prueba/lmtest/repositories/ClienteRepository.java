package com.loyalty.prueba.lmtest.repositories;

import com.loyalty.prueba.lmtest.pojo.database.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ClienteRepository extends JpaRepository<Cliente, String> {

    @Query(value = "SELECT 1 from usuario where user_id = :userId AND user_password = :userPassword", nativeQuery = true)
    int verifyCredentials(@Param("userId") String userid, @Param("userPassword") String userPassword);
}
