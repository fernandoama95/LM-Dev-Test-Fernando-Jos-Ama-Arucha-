package com.loyalty.prueba.lmtest.process;

import com.loyalty.prueba.lmtest.pojo.database.Account;
import com.loyalty.prueba.lmtest.pojo.database.Beneficiario;
import com.loyalty.prueba.lmtest.pojo.database.Cliente;
import com.loyalty.prueba.lmtest.pojo.database.CompositeBenID;
import com.loyalty.prueba.lmtest.pojo.requests.BeneficiaryRequest;
import com.loyalty.prueba.lmtest.repositories.AccountRepository;
import com.loyalty.prueba.lmtest.repositories.BeneficiaryRepository;
import com.loyalty.prueba.lmtest.repositories.ClienteRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class EditBeneficiaryProcess {
    private ClienteRepository clienteRepository;
    private BeneficiaryRepository beneficiaryRepository;
    private AccountRepository accountRepository;
    /*La operación será expuesta por medio de un método PATCH.
             La estructura de la url de consumo del servicio debe ser de la forma …/beneficiaryID, donde, beneficiaryID es el identificador único del beneficiario.
 El cuerpo de entrada debe contener el campo del correo electrónico.
 Se debe validar que el ID del beneficiario sea válido y pertenezca al cliente, caso contrario se responderá con estado HTTP 404.
             Se debe validar que el correo electrónico sea válido, caso contrario responder con estado HTTP 400.
             Si la operación es exitosa se debe responder con un estado HTTP 204, sin cuerpo de respuesta.*/

    public EditBeneficiaryProcess(ClienteRepository clienteRepository, BeneficiaryRepository beneficiaryRepository, AccountRepository accountRepository) {
        this.clienteRepository = clienteRepository;
        this.beneficiaryRepository = beneficiaryRepository;
        this.accountRepository = accountRepository;
    }

    public ResponseEntity<?> editBeneficiary(BeneficiaryRequest request, String clienteId, int beneficiaryID){
        Cliente cliente = clienteRepository.verifyCredentials(clienteId);
        if(cliente!= null){
            CompositeBenID compositeBenID = new CompositeBenID();
            Beneficiario beneficiario = new Beneficiario();
            beneficiario.setBenId(compositeBenID);
            beneficiario = beneficiaryRepository.getBeneficiarioById(beneficiaryID,clienteId,request.getAccountId());
            if(beneficiario == null){
                return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
            }
            Account account = accountRepository.getBeneficiaryAccount(request.getAccountId(),cliente.getClienteId(), request.getTipoCuenta());
            if(account != null){
                //beneficiaryRepository.
                return new ResponseEntity<>(null, HttpStatus.NO_CONTENT);
            }else{
                return new ResponseEntity<>("Invalid Beneficiary Account", HttpStatus.NOT_FOUND);
            }
        }
        return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
    }


}
