package com.loyalty.prueba.lmtest.process;

import com.loyalty.prueba.lmtest.pojo.database.Cliente;
import com.loyalty.prueba.lmtest.pojo.requests.LogInRequest;
import com.loyalty.prueba.lmtest.repositories.ClienteRepository;
import com.loyalty.prueba.lmtest.repositories.LogRequestRepository;

public class VerifyProcess {
    private ClienteRepository clienteRepository;
    private LogRequestRepository logRequestRepository;
    public VerifyProcess(ClienteRepository clienteRepository, LogRequestRepository logRequestRepository) {
        this.clienteRepository = clienteRepository;
        this.logRequestRepository = logRequestRepository;
    }

    public int process(LogInRequest request){
        LogInVerificator logInVerificator = new LogInVerificator();
        Cliente cliente = clienteRepository.verifyCredentials(request.getUserId());
        int resp = 3;
        Boolean attemp = false;
        if(cliente != null) {
            if(cliente.getClienteStatus().equals("B")){
                 return resp =2; //5 o mas intentos cuenta bloqueada
            }
            int contAttemps = logRequestRepository.attempNumberByClient(cliente.getClienteId());
            attemp = logInVerificator.verificator(cliente,request);
            if(attemp){
                logRequestRepository.deleteLogAttemps(cliente.getClienteId());
                resp = 0;//loggeo exitoso
            }else{
                if(contAttemps < 5){
                    logRequestRepository.insertNewLogAttemp(cliente.getClienteId());
                    resp = 1;//loggeo fallido
                }else{
                    clienteRepository.blockClient(cliente.getClienteId());
                    resp =2; //5 o mas intentos cuenta bloqueada
                }
            }
        }
        return resp;
    }


}