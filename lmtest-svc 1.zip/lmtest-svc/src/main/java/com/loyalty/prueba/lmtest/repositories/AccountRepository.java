package com.loyalty.prueba.lmtest.repositories;

import com.loyalty.prueba.lmtest.pojo.database.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface AccountRepository extends JpaRepository<Account,String> {

    @Query(value = "SELECT * FROM LIFEBANK.ACCOUNT WHERE AC_CLI_ID = (:clientID)", nativeQuery = true)
    List<Account> getAccountsByClient(@Param("clientID") String clientID);

    @Query(value = "SELECT * FROM LIFEBANK.ACCOUNT WHERE AC_ID = (:accountID)", nativeQuery = true)
    Account getAccountByID(@Param("accountID") String accountID);

    @Query(value = "SELECT * FROM LIFEBANK.ACCOUNT WHERE AC_ID = (:accountID) and AC_CLI_ID != (:clienteID) and AC_PROD_ID = :tipoCuenta", nativeQuery = true)
    Account getBeneficiaryAccount(@Param("accountID") String accountID, @Param("clienteID") String clienteID, @Param("tipoCuenta") int tipoCuenta);
}
