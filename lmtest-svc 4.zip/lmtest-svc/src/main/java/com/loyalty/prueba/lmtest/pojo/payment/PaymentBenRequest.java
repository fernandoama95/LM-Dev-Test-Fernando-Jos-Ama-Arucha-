package com.loyalty.prueba.lmtest.pojo.payment;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "idAccountPrinc",
        "idBeneficiario",
        "amount"
})
public class PaymentBenRequest {

    @JsonProperty("idAccountPrinc")
    private String idAccountPrinc;
    @JsonProperty("idBeneficiario")
    private String idBeneficiario;
    @JsonProperty("amount")
    private Integer amount;

    @JsonProperty("idAccountPrinc")
    public String getIdAccountPrinc() {
        return idAccountPrinc;
    }

    @JsonProperty("idAccountPrinc")
    public void setIdAccountPrinc(String idAccountPrinc) {
        this.idAccountPrinc = idAccountPrinc;
    }

    @JsonProperty("idBeneficiario")
    public String getIdBeneficiario() {
        return idBeneficiario;
    }

    @JsonProperty("idBeneficiario")
    public void setIdBeneficiario(String idBeneficiario) {
        this.idBeneficiario = idBeneficiario;
    }

    @JsonProperty("amount")
    public Integer getAmount() {
        return amount;
    }

    @JsonProperty("amount")
    public void setAmount(Integer amount) {
        this.amount = amount;
    }

}