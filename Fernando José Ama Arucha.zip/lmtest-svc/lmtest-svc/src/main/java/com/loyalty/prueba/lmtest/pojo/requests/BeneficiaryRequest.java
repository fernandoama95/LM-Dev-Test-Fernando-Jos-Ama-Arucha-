package com.loyalty.prueba.lmtest.pojo.requests;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "accountId",
        "name",
        "apellido",
        "tipoCuenta",
        "email"
})
public class BeneficiaryRequest {

    @JsonProperty("accountId")
    private String accountId;
    @JsonProperty("name")
    private String name;
    @JsonProperty("tipoCuenta")
    private Integer tipoCuenta;
    @JsonProperty("apellido")
    private String apellido;
    @JsonProperty("email")
    private String email;

    @JsonProperty("accountId")
    public String getAccountId() {
        return accountId;
    }

    @JsonProperty("accountId")
    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("tipoCuenta")
    public Integer getTipoCuenta() {
        return tipoCuenta;
    }

    @JsonProperty("tipoCuenta")
    public void setTipoCuenta(Integer tipoCuenta) {
        this.tipoCuenta = tipoCuenta;
    }

    @JsonProperty("email")
    public String getEmail() {
        return email;
    }

    @JsonProperty("email")
    public void setEmail(String email) {
        this.email = email;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
}