package com.loyalty.prueba.lmtest.process;

import com.loyalty.prueba.lmtest.pojo.database.Account;
import com.loyalty.prueba.lmtest.pojo.database.Beneficiario;
import com.loyalty.prueba.lmtest.pojo.database.Cliente;
import com.loyalty.prueba.lmtest.pojo.requests.BeneficiaryRequest;
import com.loyalty.prueba.lmtest.pojo.requests.UpdateBeneficiaryRequest;
import com.loyalty.prueba.lmtest.repositories.AccountRepository;
import com.loyalty.prueba.lmtest.repositories.BeneficiaryRepository;
import com.loyalty.prueba.lmtest.repositories.ClienteRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BeneficiaryValidationProcess {
    private ClienteRepository clienteRepository;
    private BeneficiaryRepository beneficiaryRepository;
    private AccountRepository accountRepository;
    private Logger log;

    public BeneficiaryValidationProcess(ClienteRepository clienteRepository, BeneficiaryRepository beneficiaryRepository, AccountRepository accountRepository) {
        this.clienteRepository = clienteRepository;
        this.beneficiaryRepository = beneficiaryRepository;
        this.accountRepository = accountRepository;
        this.log = LoggerFactory.getLogger(this.getClass());
    }

    public int beneficiaryValidator(BeneficiaryRequest request, String clienteId){
        log.info("Searching cliente");
        Cliente cliente = clienteRepository.verifyCredentials(clienteId);
        if(cliente == null){
            log.info("Client not found");
            return 1;//no client
        }
        Account account = accountRepository.getBeneficiaryAccount(request.getAccountId(),cliente.getClienteId(), request.getTipoCuenta());
        if(account == null){
            log.info("Account not found");
            return 2;//invalid account
        }
        if(beneficiaryRepository.isBeneficiary(cliente.getClienteId(),request.getAccountId()) == 0) {
            log.info("Beneficiary doesn't exist");
            return 0;//doesn't exists
        }else{
            log.info("Beneficiary exist");
            return 3;//beneficiary exist
        }
    }

    public int beneficiaryValidator(UpdateBeneficiaryRequest request, String clienteId){
        log.info("Searching cliente");
        Cliente cliente = clienteRepository.verifyCredentials(clienteId);
        if(cliente == null){
            log.info("Client not found");
            return 1;//no client
        }
        Account account = accountRepository.getAccountByIDAndClient("",cliente.getClienteId());
        if(account == null){
            log.info("Account not found");
            return 2;//invalid account
        }
        if(beneficiaryRepository.isBeneficiary(cliente.getClienteId(),"") == 0) {
            log.info("Beneficiary doesn't exist");
            return 0;//doesn't exists
        }else{
            log.info("Beneficiary exist");
            return 3;//beneficiary exist
        }
    }

    public int beneficiaryValidator(UpdateBeneficiaryRequest request,String beneficiaryID, String clienteId){
        log.info("Searching cliente");
        Cliente cliente = clienteRepository.verifyCredentials(clienteId);
        if(cliente == null){
            log.info("Client not found");
            return 1;//no client
        }
        Beneficiario beneficiario = beneficiaryRepository.getBeneficiarioByIdAndClient(beneficiaryID, clienteId);
        if(beneficiario==null){
            log.info("Beneficiary not found");
            return 2;
        }
        log.info("Beneficiary founded");
        return 0;//founded
    }

    public int beneficiaryValidator(String idAccount, String clienteId){
        log.info("Searching cliente");
        Cliente cliente = clienteRepository.verifyCredentials(clienteId);
        if(cliente == null){
            log.info("Client not found");
            return 1;//no client
        }
        Account account = accountRepository.getAccountByIDAndClient(idAccount,cliente.getClienteId());
        if(account == null){
            log.info("Account not found");
            return 2;//invalid account
        }
        if(beneficiaryRepository.isBeneficiary(cliente.getClienteId(),idAccount) == 0) {
            log.info("Beneficiary doesn't exist");
            return 0;//doesn't exists
        }else{
            log.info("Beneficiary exist");
            return 3;//beneficiary exist
        }
    }

}
