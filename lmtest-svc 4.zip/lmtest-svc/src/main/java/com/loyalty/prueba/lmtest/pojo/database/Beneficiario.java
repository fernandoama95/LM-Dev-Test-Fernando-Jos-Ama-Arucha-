package com.loyalty.prueba.lmtest.pojo.database;

import javax.persistence.*;

@Entity(name="BENEFICIARIO")
public class Beneficiario {
    @Id
    @Column(name = "ben_id")
    private String benId;

    @Column(name = "ben_cli_id")
    private String clienteId;

    @Column(name = "ben_ac_ben")
    private String accountId;

    @Column(name = "ben_nombre")
    private String benName;

    @Column(name = "ben_apellido")
    private String benApellido;

    @Column(name = "ben_email")
    private String benEmail;

    public String getBenName() {
        return benName;
    }

    public void setBenName(String benName) {
        this.benName = benName;
    }

    public String getBenApellido() {
        return benApellido;
    }

    public void setBenApellido(String benApellido) {
        this.benApellido = benApellido;
    }

    public String getBenEmail() {
        return benEmail;
    }

    public void setBenEmail(String benEmail) {
        this.benEmail = benEmail;
    }

    public String getBenId() {
        return benId;
    }

    public void setBenId(String benId) {
        this.benId = benId;
    }

    public String getClienteId() {
        return clienteId;
    }

    public void setClienteId(String clienteId) {
        this.clienteId = clienteId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }
}
