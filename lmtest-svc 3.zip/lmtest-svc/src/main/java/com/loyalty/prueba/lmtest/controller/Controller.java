package com.loyalty.prueba.lmtest.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.loyalty.prueba.lmtest.pojo.payment.PaymentBenRequest;
import com.loyalty.prueba.lmtest.pojo.payment.PaymentRequest;
import com.loyalty.prueba.lmtest.pojo.requests.BeneficiaryRequest;
import com.loyalty.prueba.lmtest.pojo.requests.LogInRequest;
import com.loyalty.prueba.lmtest.pojo.responses.AccountsResponse;
import com.loyalty.prueba.lmtest.pojo.responses.GeneralErrorResponse;
import com.loyalty.prueba.lmtest.pojo.responses.JWTResponse;
import com.loyalty.prueba.lmtest.process.*;
import com.loyalty.prueba.lmtest.repositories.*;
import com.loyalty.prueba.lmtest.utility.JWT;
import org.slf4j.Logger;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/test")
public class Controller {
    @Autowired
    private Environment env;
    @Autowired
    private ClienteRepository clienteRepository;
    @Autowired
    private LogRequestRepository logRequestRepository;
    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private TransactionRepository transactionRepository;
    @Autowired
    private BeneficiaryRepository beneficiaryRepository;
    private static  int TRANSEFERENCIA = 1;
    private static  int PAGO_CC = 2;
    private static  int PAGO_LOAN = 3;
    private ObjectMapper objectMapper = new ObjectMapper();

    private Logger log = LoggerFactory.getLogger(this.getClass());



    @GetMapping("/get-client-info/{idCliente}")
    public ResponseEntity<?> getClientInfo(@PathVariable String idCliente, @RequestHeader String authorization){
        try{
        LandingProcess landingProcess = new LandingProcess(accountRepository, clienteRepository);
        JWTHandler jwtHandler = new JWTHandler();
        log.info("Valores recibidos Cuenta: " + idCliente);
        switch (jwtHandler.validateJWT(authorization,env.getProperty("ipAddress"))){
            case 0:
                AccountsResponse response = landingProcess.process(idCliente);
                if(response != null){
                    return new ResponseEntity<>(response,HttpStatus.OK);
                }else{
                    return new ResponseEntity<>(new GeneralErrorResponse("BAD_REQUEST"),HttpStatus.BAD_REQUEST);
                }
            case 1:
                return new ResponseEntity<>(new GeneralErrorResponse("UnAuthorized"),HttpStatus.UNAUTHORIZED);
            case 2:
                return new ResponseEntity<>(new GeneralErrorResponse("Forbidden"),HttpStatus.FORBIDDEN);
            default:
                return new ResponseEntity<>(new GeneralErrorResponse("Service Unavailable"),HttpStatus.SERVICE_UNAVAILABLE);
        }
        }catch(Exception e){
            e.printStackTrace();
            log.error(e.getMessage());
            return new ResponseEntity<>(new GeneralErrorResponse("Service Unavailable"), HttpStatus.SERVICE_UNAVAILABLE);
        }

    }

    @GetMapping("/transaction/{idAccount}")
    public ResponseEntity<?> getTransactions(@PathVariable String idAccount,@RequestParam String startDate, @RequestParam String endDate,@RequestParam int prd, @RequestHeader String authorization){
        try{
        TransactionProcess landingProcess = new TransactionProcess(accountRepository, transactionRepository);
        JWTHandler jwtHandler = new JWTHandler();
        log.info("Valores recibidos Cuenta: " + idAccount + ", StartDate: " + startDate +  ", EndDate: " + endDate);
        switch (jwtHandler.validateJWT(authorization,env.getProperty("ipAddress"))){
            case 0:
                return landingProcess.process(jwtHandler.getClienteID(),idAccount,startDate,endDate, prd);
            case 1:
                return new ResponseEntity<>(new GeneralErrorResponse("UnAuthorized"),HttpStatus.UNAUTHORIZED);
            case 2:
                return new ResponseEntity<>(new GeneralErrorResponse("Forbidden"),HttpStatus.FORBIDDEN);
            default:
                return new ResponseEntity<>(new GeneralErrorResponse("Service Unavailable"),HttpStatus.SERVICE_UNAVAILABLE);
        }
        }catch(Exception e){
            e.printStackTrace();
            log.error(e.getMessage());
            return new ResponseEntity<>(new GeneralErrorResponse("Service Unavailable"), HttpStatus.SERVICE_UNAVAILABLE);
        }

        }

    @PostMapping("/log-in")
    public ResponseEntity<?> logIn(@RequestBody LogInRequest request){
        VerifyProcess verifyProcess = new VerifyProcess(clienteRepository, logRequestRepository);
        try {
            log.info("Request Recibido: " + objectMapper.writeValueAsString(request));
            int response = verifyProcess.process(request);
            JWTHandler jwtHandler = new JWTHandler();
            switch (response) {
                case 1://loggeo fallido
                    return new ResponseEntity<>(new GeneralErrorResponse("Credenciales incorrectas"), HttpStatus.UNAUTHORIZED);
                case 2://cuenta bloqueada
                    return new ResponseEntity<>(new GeneralErrorResponse("User Blocked"), HttpStatus.BAD_REQUEST);
                case 0://exito
                    JWTResponse jwtResponse = new JWTResponse();
                    jwtResponse.setTkn(jwtHandler.getEncrypt(request.getUserId(), env.getProperty("ipAddress")));
                    return new ResponseEntity<>(jwtResponse, HttpStatus.OK);
                default://unexpected error
                    return new ResponseEntity<>(new GeneralErrorResponse("Unknown Error"), HttpStatus.SERVICE_UNAVAILABLE);
            }
        }catch (Exception e){
            e.printStackTrace();
            log.error(e.getMessage());
            return new ResponseEntity<>(new GeneralErrorResponse("Unknown Error"), HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

    @PostMapping("/transfer")
    public ResponseEntity<?> transfer(@RequestBody PaymentRequest request, @RequestHeader String authorization){
        try {
            PaymentProcess paymentProcess = new PaymentProcess(clienteRepository, beneficiaryRepository, accountRepository, transactionRepository);
            log.info("Request Recibido: " + objectMapper.writeValueAsString(request));
            JWTHandler jwtHandler = new JWTHandler();
            switch (jwtHandler.validateJWT(authorization, env.getProperty("ipAddress"))) {
                case 0:
                    log.info("Transfer Process - Sending request to Payment Process");
                    return paymentProcess.process(request, jwtHandler.getClienteID(), TRANSEFERENCIA);
                case 1:
                    return new ResponseEntity<>(new GeneralErrorResponse("UnAuthorized"), HttpStatus.UNAUTHORIZED);
                case 2:
                    return new ResponseEntity<>(new GeneralErrorResponse("Forbidden"), HttpStatus.FORBIDDEN);
                default:
                    return new ResponseEntity<>(new GeneralErrorResponse("Service Unavailable"), HttpStatus.SERVICE_UNAVAILABLE);
            }
        }catch(Exception e){
            e.printStackTrace();
            log.error(e.getMessage());
            return new ResponseEntity<>(new GeneralErrorResponse("Service Unavailable"), HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

    @PostMapping("/pay/loan")
    public ResponseEntity<?> loanPayment(@RequestBody PaymentRequest request, @RequestHeader String authorization){
        try{
        PaymentProcess paymentProcess = new PaymentProcess(clienteRepository,beneficiaryRepository,accountRepository,transactionRepository);
        log.info("Request recibido: " + objectMapper.writeValueAsString(request));
        JWTHandler jwtHandler = new JWTHandler();
        switch (jwtHandler.validateJWT(authorization,env.getProperty("ipAddress"))){
            case 1:
                return new ResponseEntity<>(new GeneralErrorResponse("UNAUTHORIZED"),HttpStatus.UNAUTHORIZED);
            case 0:
                log.info("Pay Loan Process - Sending request to Payment Process");
                return paymentProcess.process(request,jwtHandler.getClienteID(),PAGO_LOAN);
            case 2:
                return new ResponseEntity<>(new GeneralErrorResponse("FORBIDDEN"),HttpStatus.FORBIDDEN);
            default:
                return new ResponseEntity<>(new GeneralErrorResponse("SERVICE_UNAVAILABLE"),HttpStatus.SERVICE_UNAVAILABLE);
        }
        }catch(Exception e){
            e.printStackTrace();
            log.error(e.getMessage());
            return new ResponseEntity<>(new GeneralErrorResponse("Service Unavailable"), HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

    @PostMapping("/pay/card")
    public ResponseEntity<?> creditCardPayment(@RequestBody PaymentRequest request, @RequestHeader String authorization){
        try{
        PaymentProcess paymentProcess = new PaymentProcess(clienteRepository,beneficiaryRepository,accountRepository,transactionRepository);
        JWTHandler jwtHandler = new JWTHandler();
        log.info("Request recibido: " + objectMapper.writeValueAsString(request));
        switch (jwtHandler.validateJWT(authorization,env.getProperty("ipAddress"))){

            case 1:
                return new ResponseEntity<>(new GeneralErrorResponse("UNAUTHORIZED"),HttpStatus.UNAUTHORIZED);
            case 2:
                return new ResponseEntity<>(new GeneralErrorResponse("FORBIDDEN"),HttpStatus.FORBIDDEN);
            case 0:
                log.info("Pay Credit Card Process - Sending request to Payment Process");
                return paymentProcess.process(request,jwtHandler.getClienteID(),PAGO_CC);
            default:
                return new ResponseEntity<>(new GeneralErrorResponse("SERVICE_UNAVAILABLE"),HttpStatus.SERVICE_UNAVAILABLE);
        }
        }catch(Exception e){
            e.printStackTrace();
            log.error(e.getMessage());
            return new ResponseEntity<>(new GeneralErrorResponse("Service Unavailable"), HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

    @PostMapping("/beneficiary/transfer")
    public ResponseEntity<?> transferBeneficiary(@RequestBody PaymentBenRequest request, @RequestHeader String authorization){
        try{
        BeneficiaryTransactionProcess paymentProcess = new BeneficiaryTransactionProcess(clienteRepository,beneficiaryRepository,accountRepository,transactionRepository);
        JWTHandler jwtHandler = new JWTHandler();
            log.info("Request recibido: " + objectMapper.writeValueAsString(request));
        switch (jwtHandler.validateJWT(authorization,env.getProperty("ipAddress"))){

            case 1:
                return new ResponseEntity<>(new GeneralErrorResponse("UnAuthorized"),HttpStatus.UNAUTHORIZED);

            case 0:
                log.info("Beneficiary-Transfer Process - Sending request to Payment Process");
                return paymentProcess.process(request,jwtHandler.getClienteID(),TRANSEFERENCIA);

            case 2:
                return new ResponseEntity<>(new GeneralErrorResponse("Forbidden"),HttpStatus.FORBIDDEN);
            default:
                return new ResponseEntity<>(new GeneralErrorResponse("Service Unavailable"),HttpStatus.SERVICE_UNAVAILABLE);
        }
        }catch(Exception e){
            e.printStackTrace();
            log.error(e.getMessage());
            return new ResponseEntity<>(new GeneralErrorResponse("Service Unavailable"), HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

    @PostMapping("/beneficiary/pay/loan")
    public ResponseEntity<?> loanBeneficiaryPayment(@RequestBody PaymentBenRequest request, @RequestHeader String authorization){
        try{
        BeneficiaryTransactionProcess paymentProcess = new BeneficiaryTransactionProcess(clienteRepository,beneficiaryRepository,accountRepository,transactionRepository);
        JWTHandler jwtHandler = new JWTHandler();
            log.info("Request recibido: " + objectMapper.writeValueAsString(request));
        switch (jwtHandler.validateJWT(authorization,env.getProperty("ipAddress"))){
            case 0:
                log.info("Beneficiary-Pay Loan Process - Sending request to Payment Process");
                return paymentProcess.process(request,jwtHandler.getClienteID(),PAGO_LOAN);
            case 1:
                return new ResponseEntity<>(new GeneralErrorResponse("UNAUTHORIZED"),HttpStatus.UNAUTHORIZED);

            case 2:
                return new ResponseEntity<>(new GeneralErrorResponse("FORBIDDEN"),HttpStatus.FORBIDDEN);
            default:
                return new ResponseEntity<>(new GeneralErrorResponse("SERVICE_UNAVAILABLE"),HttpStatus.SERVICE_UNAVAILABLE);
        }
        }catch(Exception e){
            e.printStackTrace();
            log.error(e.getMessage());
            return new ResponseEntity<>(new GeneralErrorResponse("Service Unavailable"), HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

    @PostMapping("/beneficiary/pay/card")
    public ResponseEntity<?> creditBeneficiaryCardPayment(@RequestBody PaymentBenRequest request, @RequestHeader String authorization){
        try{
        BeneficiaryTransactionProcess paymentProcess = new BeneficiaryTransactionProcess(clienteRepository,beneficiaryRepository,accountRepository,transactionRepository);
        JWTHandler jwtHandler = new JWTHandler();
            log.info("Request recibido: " + objectMapper.writeValueAsString(request));
        switch (jwtHandler.validateJWT(authorization,env.getProperty("ipAddress"))){
            case 2:
                return new ResponseEntity<>(new GeneralErrorResponse("FORBIDDEN"),HttpStatus.FORBIDDEN);

            case 1:
                return new ResponseEntity<>(new GeneralErrorResponse("UNAUTHORIZED"),HttpStatus.UNAUTHORIZED);

            case 0:
                log.info("Beneficiary-Pay Credit Card Process - Sending request to Payment Process");
                return paymentProcess.process(request,jwtHandler.getClienteID(),PAGO_CC);
            default:
                return new ResponseEntity<>(new GeneralErrorResponse("SERVICE_UNAVAILABLE"),HttpStatus.SERVICE_UNAVAILABLE);
        }
        }catch(Exception e){
            e.printStackTrace();
            log.error(e.getMessage());
            return new ResponseEntity<>(new GeneralErrorResponse("Service Unavailable"), HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

    @PostMapping("/beneficiary/add")
    public ResponseEntity<?> addBeneficiario(@RequestBody BeneficiaryRequest request, @RequestHeader String authorization){
        try {
            AddBeneficiaryProcess addBeneficiaryProcess = new AddBeneficiaryProcess(clienteRepository, beneficiaryRepository, accountRepository);
            JWTHandler jwtHandler = new JWTHandler();
            log.info("Request recibido: " + objectMapper.writeValueAsString(request));
            switch (jwtHandler.validateJWT(authorization, env.getProperty("ipAddress"))) {
                case 0:
                    log.info("Add Beneficiary Process");
                    return addBeneficiaryProcess.addBeneficiary(request, jwtHandler.getClienteID());
                case 1:
                    return new ResponseEntity<>(new GeneralErrorResponse("UNAUTHORIZED"), HttpStatus.UNAUTHORIZED);
                case 2:
                    return new ResponseEntity<>(new GeneralErrorResponse("FORBIDDEN"), HttpStatus.FORBIDDEN);
                default:
                    return new ResponseEntity<>(new GeneralErrorResponse("SERVICE_UNAVAILABLE"), HttpStatus.SERVICE_UNAVAILABLE);
            }
        }catch(Exception e){
            e.printStackTrace();
            log.error(e.getMessage());
            return new ResponseEntity<>(new GeneralErrorResponse("Service Unavailable"), HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

    @PatchMapping("/beneficiary/edit/{beneficiaryID}")
    public ResponseEntity<?> editBeneficiario(@PathVariable String beneficiaryID, @RequestBody BeneficiaryRequest request, @RequestHeader String authorization){
        try {
            EditBeneficiaryProcess editBeneficiaryProcess = new EditBeneficiaryProcess(clienteRepository, beneficiaryRepository, accountRepository);
            JWTHandler jwtHandler = new JWTHandler();
            log.info("Request recibido: " + objectMapper.writeValueAsString(request));
            switch (jwtHandler.validateJWT(authorization, env.getProperty("ipAddress"))) {
                case 0:
                    log.info("Edit Beneficiary Process");
                    return editBeneficiaryProcess.editBeneficiary(request, jwtHandler.getClienteID(), beneficiaryID);
                case 1:
                    return new ResponseEntity<>(new GeneralErrorResponse("UNAUTHORIZED"), HttpStatus.UNAUTHORIZED);
                case 2:
                    return new ResponseEntity<>(new GeneralErrorResponse("FORBIDDEN"), HttpStatus.FORBIDDEN);
                default:
                    return new ResponseEntity<>(new GeneralErrorResponse("SERVICE_UNAVAILABLE"), HttpStatus.SERVICE_UNAVAILABLE);
            }
        }catch(Exception e){
        e.printStackTrace();
        log.error(e.getMessage());
        return new ResponseEntity<>(new GeneralErrorResponse("Service Unavailable"), HttpStatus.SERVICE_UNAVAILABLE);
    }
    }

    @DeleteMapping("/beneficiary/delete/{beneficiaryID}")
    public ResponseEntity<?> deleteBeneficiary(@PathVariable String beneficiaryID,@RequestBody BeneficiaryRequest request, @RequestHeader String authorization){
        try {
            DeleteBeneficiaryProcess deleteBeneficiaryProcess = new DeleteBeneficiaryProcess(clienteRepository, beneficiaryRepository, accountRepository);
            JWTHandler jwtHandler = new JWTHandler();
            log.info("Request recibido: " + objectMapper.writeValueAsString(request));
            switch (jwtHandler.validateJWT(authorization, env.getProperty("ipAddress"))) {
                case 0:
                    log.info("Delete Beneficiary process");
                    return deleteBeneficiaryProcess.deleteBeneficiary(request, jwtHandler.getClienteID(), beneficiaryID);
                case 1:
                    return new ResponseEntity<>(new GeneralErrorResponse("UNAUTHORIZED"), HttpStatus.UNAUTHORIZED);
                case 2:
                    return new ResponseEntity<>(new GeneralErrorResponse("FORBIDDEN"), HttpStatus.FORBIDDEN);
                default:
                    return new ResponseEntity<>(new GeneralErrorResponse("SERVICE_UNAVAILABLE"), HttpStatus.SERVICE_UNAVAILABLE);
            }
        }catch(Exception e){
            e.printStackTrace();
            log.error(e.getMessage());
            return new ResponseEntity<>(new GeneralErrorResponse("Service Unavailable"), HttpStatus.SERVICE_UNAVAILABLE);
    }
    }
}
