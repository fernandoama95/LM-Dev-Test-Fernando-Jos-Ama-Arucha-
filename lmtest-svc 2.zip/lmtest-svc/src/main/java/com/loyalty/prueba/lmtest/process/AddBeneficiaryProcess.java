package com.loyalty.prueba.lmtest.process;

import com.loyalty.prueba.lmtest.pojo.database.Account;
import com.loyalty.prueba.lmtest.pojo.database.Cliente;
import com.loyalty.prueba.lmtest.pojo.requests.BeneficiaryRequest;
import com.loyalty.prueba.lmtest.repositories.AccountRepository;
import com.loyalty.prueba.lmtest.repositories.BeneficiaryRepository;
import com.loyalty.prueba.lmtest.repositories.ClienteRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class AddBeneficiaryProcess {
    private ClienteRepository clienteRepository;
    private BeneficiaryRepository beneficiaryRepository;
    private AccountRepository accountRepository;
    public AddBeneficiaryProcess(ClienteRepository clienteRepository, BeneficiaryRepository beneficiaryRepository, AccountRepository accountRepository) {
        this.clienteRepository = clienteRepository;
        this.beneficiaryRepository = beneficiaryRepository;
        this.accountRepository = accountRepository;
    }

    public ResponseEntity<?> addBeneficiary(BeneficiaryRequest request, String clienteId){
        BeneficiaryValidationProcess beneficiaryValidationProcess = new BeneficiaryValidationProcess(clienteRepository,beneficiaryRepository,accountRepository);
        int validator = beneficiaryValidationProcess.beneficiaryValidator(request,clienteId);

        if(validator == 1){
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
        if(validator == 2){
            return new ResponseEntity<>("Invalid Beneficiary Account", HttpStatus.NOT_FOUND);
        }
        if(validator == 3) {
            return new ResponseEntity<>(null, HttpStatus.CONFLICT);
        }
        beneficiaryRepository.addBeneficiary(clienteId,request.getAccountId(), request.getName(),request.getName(), request.getEmail());
        return new ResponseEntity<>(null, HttpStatus.CREATED);
}
}
