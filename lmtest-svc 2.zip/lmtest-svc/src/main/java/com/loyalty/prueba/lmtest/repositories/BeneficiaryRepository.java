package com.loyalty.prueba.lmtest.repositories;

import com.loyalty.prueba.lmtest.pojo.database.Beneficiario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface BeneficiaryRepository extends JpaRepository<Beneficiario,Integer> {
    @Modifying(clearAutomatically = true)
    @Query(value="insert into lifebank.beneficiario(ben_cli_id,ben_ac_ben,ben_nombre,ben_apellido,ben_email) values (:clienteID,:benefID,:nombre,:apellido,:email)",nativeQuery = true)
    @Transactional(rollbackFor = {Exception.class})
    int addBeneficiary(@Param("clienteID") String clienteID, @Param("benefID") String benefID, @Param("nombre") String nombre, @Param("apellido") String apellido,@Param("email") String email);

    @Modifying(clearAutomatically = true)
    @Query(value="update lifebank.beneficiario set ben_nombre = :nombre, ben_apellido = :apellido, ben_email = :email where ben_id = :benId and ben_cli_id = :clienteID and ben_ac_ben = :benefID",nativeQuery = true)
    @Transactional(rollbackFor = {Exception.class})
    int updateBeneficiary(@Param("clienteID") String clienteID,@Param("benId") int benId, @Param("benefID") String benefID, @Param("nombre") String nombre, @Param("apellido") String apellido,@Param("email") String email);

    @Modifying(clearAutomatically = true)
    @Query(value="delete from lifebank.beneficiario where ben_id = :benId and ben_cli_id = :clienteID and ben_ac_ben = :benefID",nativeQuery = true)
    @Transactional(rollbackFor = {Exception.class})
    int deleteBeneficiary(@Param("clienteID") String clienteID,@Param("benId") int benId, @Param("benefID") String benefID);


    @Query(value = "select count(ben_id) from lifebank.beneficiario where ben_cli_id = (:clienteID) and ben_ac_ben = (:beneID)",  nativeQuery = true)
    int isBeneficiary(@Param("clienteID") String clienteId, @Param("beneID") String beneID);

    @Query(value = "select * from lifebank.beneficiario where ben_id = (:benId)and ben_cli_id = (:clienteID) and ben_ac_ben = (:acBenId)",  nativeQuery = true)
    Beneficiario getBeneficiarioById(@Param("benId") int benId,@Param("clienteID") String clienteId, @Param("acBenId") String acBenId);
}
