package com.loyalty.prueba.lmtest.pojo.payment;

public class PaymentRequest {
}
