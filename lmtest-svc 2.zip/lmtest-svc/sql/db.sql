drop schema lifebank cascade;

create schema lifebank;

create table lifebank.cliente(
	cli_id varchar(10) not null,
	cli_name varchar(50) null,
	cli_apellido varchar(50) null,
	cli_password varchar(500),
	cli_estado_cliente varchar(2),
	cli_fecha_nac timestamptz,
	CONSTRAINT cli_pkey PRIMARY KEY (cli_id)
);

create table lifebank.logs_request(
	log_id serial not null,
	log_cli_id varchar(10),
	constraint log_pkey primary key (log_id),
	constraint log_fkey foreign key (log_cli_id) REFERENCES lifebank.cliente (cli_id)
);

create table lifebank.producto(
	prod_id int not null,
	prod_tipo varchar(2),
	CONSTRAINT prod_pkey PRIMARY KEY (prod_id)
	);

create table lifebank.account(
	ac_id varchar(10) not null,
	ac_cli_id varchar(20) not null,
	ac_duracion int,
	ac_prod_id int,
	ac_total numeric(10,2),
	ac_limit numeric(10,2),
	ac_available numeric(10,2),
	ac_name varchar(100),
	ac_debt numeric(10,2),
	ac_interes numeric(5,2),
	ac_interes_amount numeric(5,2),
	ac_fecha_ingreso timestamptz,
	CONSTRAINT ac_pkey PRIMARY KEY (ac_id),
	constraint ac_fkey FOREIGN KEY (ac_cli_id) REFERENCES lifebank.cliente (cli_id),
	constraint ac_prod_fkey FOREIGN KEY (ac_prod_id) REFERENCES lifebank.producto (prod_id)
);

create table lifebank.transaccion(
	tra_id serial not null,
	tra_ac_id varchar(10) not null,
	tra_date timestamptz,
	tra_description text,
	tra_amount numeric(5,2),
	CONSTRAINT tra_pkey PRIMARY KEY (tra_id),
	constraint tra_fkey FOREIGN KEY (tra_ac_id) REFERENCES lifebank.account (ac_id)
);


create table lifebank.beneficiario(
	ben_id serial not null,
	ben_cli_id varchar(10) not null, --Id cliente
	ben_ac_ben varchar(10) not null, -- Id de la cuenta del beneficiaro
	ben_nombre varchar(50),
	ben_apellido varchar(50),
	ben_email varchar(50),
	CONSTRAINT ben_pkey PRIMARY KEY (ben_id,ben_cli_id, ben_ac_ben),
	constraint ben_fkey1 FOREIGN KEY (ben_cli_id) REFERENCES lifebank.cliente (cli_id),
	constraint ben_fkey2 foreign key (ben_ac_ben) references lifebank.account (ac_id)
);

update lifebank.account set ac_available = 0.00, ac_limit = 0.00 where ac_id = 'AE0000001';

INSERT INTO lifebank.producto
(prod_id, prod_tipo)
VALUES(1, 'SA');
INSERT INTO lifebank.producto
(prod_id, prod_tipo)
VALUES(2, 'CA');
INSERT INTO lifebank.producto
(prod_id, prod_tipo)
VALUES(3, 'LA');

INSERT INTO lifebank.cliente
(cli_id, cli_name, cli_apellido, cli_password, cli_estado_cliente, cli_fecha_nac)
VALUES('12345678-1', 'Fernando', 'Ama', 'da23cdf637db97c80b0692d5bcb9b1b44f92f2e6ff1fda95c09a5d40f1e4ee5b269acae63666b1611501fe9abdc379b282646166c8c401000917321202960c46', 'A', '2019-04-13 19:30:25.000');
INSERT INTO lifebank.cliente
(cli_id, cli_name, cli_apellido, cli_password, cli_estado_cliente, cli_fecha_nac)
VALUES('8754321-2', 'José', 'Ama', 'asdfgh', 'A', '2019-04-13 19:30:25.000');

INSERT INTO lifebank.account
(ac_id, ac_cli_id, ac_duracion, ac_prod_id, ac_total, ac_limit, ac_available, ac_name, ac_debt, ac_interes, ac_interes_amount, ac_fecha_ingreso)
VALUES('AE0000001', '12345678-1', 0, 1, 12345.74, 0.00, 0.00, 'Fernando Ama', 0.00, 5.25, 125.43, '2019-04-13 19:30:25.000');
INSERT INTO lifebank.account
(ac_id, ac_cli_id, ac_duracion, ac_prod_id, ac_total, ac_limit, ac_available, ac_name, ac_debt, ac_interes, ac_interes_amount, ac_fecha_ingreso)
VALUES('AE0000002', '12345678-1', 0, 2, 0.00, 4500.00, 3265.16, 'Fernando Ama', 0.00, 0.00, 0.00, '2019-04-13 19:30:25.000');
INSERT INTO lifebank.account
(ac_id, ac_cli_id, ac_duracion, ac_prod_id, ac_total, ac_limit, ac_available, ac_name, ac_debt, ac_interes, ac_interes_amount, ac_fecha_ingreso)
VALUES('AE0000003', '12345678-1', 24, 3, 7500.00, 0.00, 0.00, 'Fernando Ama', 3250.43, 5.25, 125.43, '2019-04-13 19:30:25.000');
INSERT INTO lifebank.account
(ac_id, ac_cli_id, ac_duracion, ac_prod_id, ac_total, ac_limit, ac_available, ac_name, ac_debt, ac_interes, ac_interes_amount, ac_fecha_ingreso)
VALUES('AE0000004', '8754321-2', 0, 1, 12345.74, 0.00, 0.00, 'Jose Ama', 0.00, 0.00, 0.00, '2019-04-13 19:30:25.000');
