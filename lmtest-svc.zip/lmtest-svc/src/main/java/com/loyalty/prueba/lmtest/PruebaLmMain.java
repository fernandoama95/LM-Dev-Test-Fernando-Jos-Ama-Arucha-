package com.loyalty.prueba.lmtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaLmMain {

    public static void main(String[] args) {
        SpringApplication.run(PruebaLmMain.class, args);
    }

}
