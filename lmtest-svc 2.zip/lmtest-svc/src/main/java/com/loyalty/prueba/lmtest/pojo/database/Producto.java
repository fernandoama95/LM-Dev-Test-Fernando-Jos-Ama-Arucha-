package com.loyalty.prueba.lmtest.pojo.database;

import javax.persistence.*;
import java.util.List;

@Entity(name="PRODUCTO")
public class Producto {
    @Id
    @Column(name="prod_id")
    private Integer productId;

    @Column(name="prod_tipo")
    private String tipoProducto;

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "ac_prod_id")
    private List<Account> accounts;

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public List<Account> getAccounts() {
        return accounts;
    }

    public void setAccounts(List<Account> accounts) {
        this.accounts = accounts;
    }

    public String getTipoProducto() {
        return tipoProducto;
    }

    public void setTipoProducto(String tipoProducto) {
        this.tipoProducto = tipoProducto;
    }
}
