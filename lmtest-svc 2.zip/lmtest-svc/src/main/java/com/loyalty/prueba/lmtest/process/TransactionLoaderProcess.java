package com.loyalty.prueba.lmtest.process;

import com.loyalty.prueba.lmtest.pojo.database.Transaccion;
import com.loyalty.prueba.lmtest.pojo.responses.Transaction;

import java.util.ArrayList;
import java.util.List;

public class TransactionLoaderProcess {
    public TransactionLoaderProcess() {
    }
    public List<Transaction> loader(List<Transaccion> tranDb){
        List<Transaction> transactions = new ArrayList<>();
        for(Transaccion tra : tranDb){
            Transaction transaction = new Transaction();
            transaction.setId(tra.getAccountId());
            transaction.setAmount(tra.getTransactionAmount());
            transaction.setDescription(tra.getTransactionDesc());
            transaction.setDate(tra.getTransactionDate().toString());
            transactions.add(transaction);
        }
        return transactions;
    }
}
