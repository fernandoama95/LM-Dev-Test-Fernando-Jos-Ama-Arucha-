package com.loyalty.prueba.lmtest.repositories;

import com.loyalty.prueba.lmtest.pojo.database.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface ClienteRepository extends JpaRepository<Cliente, String> {

    @Query(value = "SELECT * from lifebank.cliente where cli_id = :userId", nativeQuery = true)
    Cliente verifyCredentials(@Param("userId") String userid);


    @Modifying(clearAutomatically = true)
    @Query(value = "UPDATE lifebank.cliente SET cli_estado_cliente = ('B') WHERE cli_id=:userId", nativeQuery = true)
    @Transactional
    int blockClient(@Param("userId") String userId);
}
