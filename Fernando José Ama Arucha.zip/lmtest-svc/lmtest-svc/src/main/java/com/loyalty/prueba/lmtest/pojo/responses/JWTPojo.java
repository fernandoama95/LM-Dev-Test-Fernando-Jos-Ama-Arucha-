package com.loyalty.prueba.lmtest.pojo.responses;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.time.LocalDateTime;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "idUser",
        "ipAddress",
        "expiration-datetime"
})
public class JWTPojo {

    @JsonProperty("idUser")
    private String idUser;
    @JsonProperty("ipAddress")
    private String ipAddress;
    @JsonProperty("expiration-datetime")
    private LocalDateTime expirationDatetime;

    @JsonProperty("idUser")
    public String getIdUser() {
        return idUser;
    }

    @JsonProperty("idUser")
    public void setIdUser(String idUser) {
        this.idUser = idUser;
    }

    @JsonProperty("ipAddress")
    public String getIpAddress() {
        return ipAddress;
    }

    @JsonProperty("ipAddress")
    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    @JsonProperty("expiration-datetime")
    public LocalDateTime getExpirationDatetime() {
        return expirationDatetime;
    }

    @JsonProperty("expiration-datetime")
    public void setExpirationDatetime(LocalDateTime expirationDatetime) {
        this.expirationDatetime = expirationDatetime;
    }
}