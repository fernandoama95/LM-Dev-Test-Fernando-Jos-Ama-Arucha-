package com.loyalty.prueba.lmtest.process;

import com.loyalty.prueba.lmtest.pojo.database.Account;
import com.loyalty.prueba.lmtest.pojo.database.Cliente;
import com.loyalty.prueba.lmtest.pojo.requests.BeneficiaryRequest;
import com.loyalty.prueba.lmtest.repositories.AccountRepository;
import com.loyalty.prueba.lmtest.repositories.BeneficiaryRepository;
import com.loyalty.prueba.lmtest.repositories.ClienteRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class BeneficiaryValidationProcess {
    private ClienteRepository clienteRepository;
    private BeneficiaryRepository beneficiaryRepository;
    private AccountRepository accountRepository;
    private Logger log;

    public BeneficiaryValidationProcess(ClienteRepository clienteRepository, BeneficiaryRepository beneficiaryRepository, AccountRepository accountRepository) {
        this.clienteRepository = clienteRepository;
        this.beneficiaryRepository = beneficiaryRepository;
        this.accountRepository = accountRepository;
        this.log = LoggerFactory.getLogger(this.getClass());
    }

    public int beneficiaryValidator(BeneficiaryRequest request, String clienteId){
        log.info("Searching cliente");
        Cliente cliente = clienteRepository.verifyCredentials(clienteId);
        if(cliente == null){
            log.info("Client not found");
            return 1;//no client
        }
        Account account = accountRepository.getBeneficiaryAccount(request.getAccountId(),cliente.getClienteId(), request.getTipoCuenta());
        if(account == null){
            log.info("Account not found");
            return 2;//invalid account
        }
        if(beneficiaryRepository.isBeneficiary(cliente.getClienteId(),request.getAccountId()) == 0) {
            log.info("Beneficiary doesn't exist");
            return 0;//doesn't exists
        }else{
            log.info("Beneficiary exist");
            return 3;//beneficiary exist
        }
    }

}
