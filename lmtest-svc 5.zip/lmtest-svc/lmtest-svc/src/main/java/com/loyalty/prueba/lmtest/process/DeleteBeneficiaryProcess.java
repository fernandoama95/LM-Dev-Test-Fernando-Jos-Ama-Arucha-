package com.loyalty.prueba.lmtest.process;

import com.loyalty.prueba.lmtest.pojo.requests.BeneficiaryRequest;
import com.loyalty.prueba.lmtest.pojo.responses.GeneralErrorResponse;
import com.loyalty.prueba.lmtest.repositories.AccountRepository;
import com.loyalty.prueba.lmtest.repositories.BeneficiaryRepository;
import com.loyalty.prueba.lmtest.repositories.ClienteRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class DeleteBeneficiaryProcess {
    private ClienteRepository clienteRepository;
    private BeneficiaryRepository beneficiaryRepository;
    private AccountRepository accountRepository;
    private Logger log;

    public DeleteBeneficiaryProcess(ClienteRepository clienteRepository, BeneficiaryRepository beneficiaryRepository, AccountRepository accountRepository) {
        this.clienteRepository = clienteRepository;
        this.beneficiaryRepository = beneficiaryRepository;
        this.accountRepository = accountRepository;
        this.log = LoggerFactory.getLogger(this.getClass());
    }

    public ResponseEntity<?> deleteBeneficiary( String clienteId, String beneficiaryID){
        try {
            BeneficiaryValidationProcess beneficiaryValidationProcess = new BeneficiaryValidationProcess(clienteRepository, beneficiaryRepository, accountRepository);
            int validator = beneficiaryValidationProcess.beneficiaryValidator(null, beneficiaryID, clienteId);

            if (validator == 1) {
                return new ResponseEntity<>(new GeneralErrorResponse("BAD_REQUEST"), HttpStatus.BAD_REQUEST);
            }
            if (validator == 2) {
                return new ResponseEntity<>(new GeneralErrorResponse("Invalid Beneficiary Account"), HttpStatus.NOT_FOUND);
            }
            beneficiaryRepository.deleteBeneficiary(clienteId, beneficiaryID);
            log.info("Beneficiary deleted successfully");
            return new ResponseEntity<>("Exito", HttpStatus.NO_CONTENT);
        }catch (Exception e){
        e.printStackTrace();
        log.error(e.getMessage());
        return new ResponseEntity<>(new GeneralErrorResponse("SERVICE_UNAVAILABLE"), HttpStatus.SERVICE_UNAVAILABLE);

    }

    }
}
