package com.loyalty.prueba.lmtest.repositories;

import com.loyalty.prueba.lmtest.pojo.database.Transaccion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public interface TransactionRepository extends JpaRepository<Transaccion, String> {
    @Query(value="select * from lifebank.transaccion where (tra_date between (:startDate) and (:endDate)) and tra_ac_id= (:accountID) order by tra_date desc", nativeQuery = true)
    List<Transaccion> getTransactionsByAccount(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endStart, @Param("accountID") String accountID);

    /*tra_id serial NOT NULL,
	tra_ac_id varchar(10) NOT NULL,
	tra_date timestamptz NULL,
	tra_description text NULL,
	tra_amount numeric(5,2) NULL,*/
    @Modifying(clearAutomatically = true)
    @Query(value="insert into lifebank.transaccion(tra_id,tra_ac_id,tra_date,tra_description,tra_amount) values (:traId,:accountId,:traDate,:descripcion,:amount)",nativeQuery = true)
    @Transactional(rollbackFor = {Exception.class})
    int addTransaccion(@Param("traId") String traId,@Param("accountId") String accountId, @Param("traDate") LocalDateTime traDate, @Param("descripcion") String descripcion, @Param("amount") double amount);
}
