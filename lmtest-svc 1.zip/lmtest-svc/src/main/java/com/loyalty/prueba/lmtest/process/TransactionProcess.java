package com.loyalty.prueba.lmtest.process;

import ch.qos.logback.core.net.server.Client;
import com.loyalty.prueba.lmtest.pojo.database.Account;
import com.loyalty.prueba.lmtest.pojo.database.Transaccion;
import com.loyalty.prueba.lmtest.pojo.responses.AccountResponse;
import com.loyalty.prueba.lmtest.pojo.responses.CreditCard;
import com.loyalty.prueba.lmtest.pojo.responses.CreditCardResponse;
import com.loyalty.prueba.lmtest.pojo.responses.PrestamoPojo;
import com.loyalty.prueba.lmtest.repositories.AccountRepository;
import com.loyalty.prueba.lmtest.repositories.ClienteRepository;
import com.loyalty.prueba.lmtest.repositories.TransactionRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

public class TransactionProcess {
    private AccountRepository accountRepository;
    private TransactionRepository transactionRepository;

    public TransactionProcess(AccountRepository accountRepository, TransactionRepository transactionRepository) {
        this.accountRepository = accountRepository;
        this.transactionRepository = transactionRepository;
    }

    public ResponseEntity<?> process(String accountId, String startDate, String endDate){
        TransactionLoaderProcess tlp = new TransactionLoaderProcess();
        LocalDate start = LocalDate.parse(startDate, DateTimeFormatter.ofPattern("yyyy-MM-dd").withLocale(Locale.ENGLISH));
        LocalDate end = LocalDate.parse(endDate, DateTimeFormatter.ofPattern("yyyy-MM-dd").withLocale(Locale.ENGLISH));
        Period p = Period.between(start, end);
        int months = p.getMonths();
        if(end.compareTo(start) == -1){
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
        if(months>3){
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
        Account account = accountRepository.getAccountByID(accountId);

        List<Transaccion> transaccions = transactionRepository.getTransactionsByAccount(start,end,accountId);
        if(account != null){
            switch (account.getIdProducto()){
                case 1:
                    AccountResponse accountResponse = new AccountResponse();
                    accountResponse.setId(account.getAcountId());
                    accountResponse.setStartDate(start.toString());
                    accountResponse.setEndDate(end.toString());
                    accountResponse.setTransactions(tlp.loader(transaccions));
                    return new ResponseEntity<>(accountResponse, HttpStatus.OK);
                case 2:
                    CreditCardResponse creditCardResponse = new CreditCardResponse();
                    creditCardResponse.setId(account.getAcountId());
                    creditCardResponse.setAvailable(account.getAccountAvailable());
                    creditCardResponse.setEndDate(end.toString());
                    creditCardResponse.setMonthlyCut(account.getDuracion());
                    creditCardResponse.setLimit((int) account.getAccountLimit());
                    creditCardResponse.setInterestAmount(account.getAccountIntAmount());
                    creditCardResponse.setInterestRate(account.getAccountInteres());
                    creditCardResponse.setStartDate(start.toString());
                    creditCardResponse.setTransactions(tlp.loader(transaccions));
                    return new ResponseEntity<>(creditCardResponse, HttpStatus.OK);
                case 3:
                    PrestamoPojo prestamoPojo = new PrestamoPojo();
                    prestamoPojo.setId(account.getAcountId());
                    prestamoPojo.setStartDate(start.toString());
                    prestamoPojo.setEndDate(end.toString());
                    prestamoPojo.setTotal((int) account.getAccountTotal());
                    prestamoPojo.setDebt(account.getAccountDebt());
                    prestamoPojo.setInterestRate(account.getAccountInteres());
                    prestamoPojo.setInterestAmount(account.getAccountIntAmount());
                    prestamoPojo.setTransactions(tlp.loader(transaccions));
                    return new ResponseEntity<>(prestamoPojo, HttpStatus.OK);
                    default:
                        return new ResponseEntity<>(null, HttpStatus.CONFLICT);
            }
        }
        return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);

    }
}
