package com.loyalty.prueba.lmtest.process;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmailValidatorProcess {
    private static String emailPattern = "^[_a-z0-9-]+(\\.[_a-z0-9-]+)*@" +
            "[a-z0-9-]+(\\.[a-z0-9-]+)*(\\.[a-z]{2,4})$";

    public static boolean validateEmail(String email){
        Pattern pattern = Pattern.compile(emailPattern);
        Matcher matcher = pattern.matcher(email);
        if (matcher.matches()) {
            return false;
        }else{
        return true;
        }
    }
}
