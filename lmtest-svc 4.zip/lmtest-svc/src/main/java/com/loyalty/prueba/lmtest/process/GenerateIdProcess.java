package com.loyalty.prueba.lmtest.process;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class GenerateIdProcess {
    public GenerateIdProcess() {
    }

    public static String generate(String head, String idCliente, String benAccount){
        String respuesta = head;
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("ddMMyyyyHHmmssSSS");
        LocalDateTime now = LocalDateTime.now();
        if(head.equals("TRA")){
            respuesta = respuesta + now.format(dateTimeFormatter);
        }
        if(head.equals("BEN")){
            respuesta = respuesta + "_" + benAccount + "_" + idCliente;
        }
        return respuesta;
    }
}
