package com.loyalty.prueba.lmtest.pojo.database;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity(name="ACCOUNT")
public class Account {
    @Id
    @Column(name="ac_id")
    private String acountId;

    @Column(name="ac_cli_id")
    private String clienteId;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "ac_cli_id", referencedColumnName = "cli_id", insertable = false, updatable = false)
    @JsonIgnore
    private Cliente clienteAccount;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "ac_prod_id", referencedColumnName = "prod_id", insertable = false, updatable = false)
    @JsonIgnore
    private Producto producto;


    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "tra_ac_id")
    private List<Transaccion> transaccions;

    @Column(name="ac_duracion")
    private Integer duracion;
    @Column(name="ac_prod_id")
    private Integer idProducto;
    @Column(name="ac_total")
    private double accountTotal;
    @Column(name="ac_debt")
    private double accountDebt;
    @Column(name="ac_available")
    private double accountAvailable;
    @Column(name="ac_limit")
    private double accountLimit;
    @Column(name="ac_name")
    private String accountName;
    @Column(name="ac_interes")
    private double accountInteres;
    @Column(name="ac_interes_amount")
    private double accountIntAmount;
    @Column(name="ac_fecha_ingreso")
    private LocalDateTime enrollDate;

    public String getAcountId() {
        return acountId;
    }

    public void setAcountId(String acountId) {
        this.acountId = acountId;
    }

    public String getClienteId() {
        return clienteId;
    }

    public void setClienteId(String clienteId) {
        this.clienteId = clienteId;
    }

    public Integer getDuracion() {
        return duracion;
    }

    public void setDuracion(Integer duracion) {
        this.duracion = duracion;
    }

    public double getAccountTotal() {
        return accountTotal;
    }

    public void setAccountTotal(double accountTotal) {
        this.accountTotal = accountTotal;
    }

    public double getAccountDebt() {
        return accountDebt;
    }

    public void setAccountDebt(double accountDebt) {
        this.accountDebt = accountDebt;
    }

    public double getAccountInteres() {
        return accountInteres;
    }

    public void setAccountInteres(double accountInteres) {
        this.accountInteres = accountInteres;
    }

    public double getAccountIntAmount() {
        return accountIntAmount;
    }

    public void setAccountIntAmount(double accountIntAmount) {
        this.accountIntAmount = accountIntAmount;
    }

    public LocalDateTime getEnrollDate() {
        return enrollDate;
    }

    public void setEnrollDate(LocalDateTime enrollDate) {
        this.enrollDate = enrollDate;
    }

    public Cliente getClienteAccount() {
        return clienteAccount;
    }

    public void setClienteAccount(Cliente clienteAccount) {
        this.clienteAccount = clienteAccount;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public List<Transaccion> getTransaccions() {
        return transaccions;
    }

    public void setTransaccions(List<Transaccion> transaccions) {
        this.transaccions = transaccions;
    }

    public Integer getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(Integer idProducto) {
        this.idProducto = idProducto;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public double getAccountAvailable() {
        return accountAvailable;
    }

    public void setAccountAvailable(double accountAvailable) {
        this.accountAvailable = accountAvailable;
    }

    public double getAccountLimit() {
        return accountLimit;
    }

    public void setAccountLimit(double accountLimit) {
        this.accountLimit = accountLimit;
    }
}
