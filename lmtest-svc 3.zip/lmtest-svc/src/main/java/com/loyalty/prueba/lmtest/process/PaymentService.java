package com.loyalty.prueba.lmtest.process;

import com.loyalty.prueba.lmtest.pojo.database.Account;
import com.loyalty.prueba.lmtest.pojo.responses.GeneralErrorResponse;
import com.loyalty.prueba.lmtest.pojo.responses.MovementResponse;
import com.loyalty.prueba.lmtest.repositories.AccountRepository;
import com.loyalty.prueba.lmtest.repositories.TransactionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class PaymentService {
    private AccountRepository accountRepository;
    private TransactionRepository transactionRepository;
    private Logger log;

    public PaymentService(AccountRepository accountRepository, TransactionRepository transactionRepository) {
        this.accountRepository = accountRepository;
        this.transactionRepository = transactionRepository;
        this.log = LoggerFactory.getLogger(this.getClass());
    }


    public ResponseEntity<?> amountMovement(Account accountOr, Account accountDest, double monto, int process) {
        switch (process) {
            case 1:
                log.info("Payment Service - Transfer procedure");
                return transfer(accountOr,accountDest,monto);
            case 2:
                log.info("Payment Service - Trying to make money movements");
                return payCreditCard(accountOr,accountDest,monto);
            case 3:
                log.info("Payment Service - Trying to make money movements");
                return payLoan(accountOr,accountDest,monto);
            default:
                return new ResponseEntity<>(new GeneralErrorResponse("Unexpected Error"), HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

    public ResponseEntity<?> payLoan(Account accountOr, Account accountDest, double monto){
        try{
            double b=0 ,c =0;
            if(accountOr.getIdProducto() != 2){
                b = accountOr.getAccountTotal() - monto;
                accountRepository.updateTotalAccount(accountOr.getAcountId(), b);
            }else{
                b = accountOr.getAccountAvailable() - monto;
                accountRepository.updateAvailableAccount(accountOr.getAcountId(), b);
            }
            c= accountDest.getAccountDebt() - monto;
            accountRepository.updateDebtAccount(accountDest.getAcountId(), c);
            String id = GenerateIdProcess.generate("TRA","","");
            LocalDateTime now  = LocalDateTime.now();
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            transactionRepository.addTransaccion(id,accountOr.getAcountId(), now,"Pago hacia cuenta de Prestamo " + accountDest.getAcountId(),monto*-1);
            transactionRepository.addTransaccion(GenerateIdProcess.generate("TRA","","")
                    ,accountDest.getAcountId(), LocalDateTime.now(),"Pago desde cuenta " + accountOr.getAcountId(),monto);

            return new ResponseEntity<>(new MovementResponse(id, now.format(dateTimeFormatter),"Pago hacia cuenta de Prestamo " + accountDest.getAcountId(), monto*-1), HttpStatus.OK);
        }catch(Exception e){
            e.printStackTrace();
            return new ResponseEntity<>(new GeneralErrorResponse("Unexpected Error"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<?> payCreditCard(Account accountOr, Account accountDest, double monto){
        try{
            double b=0 ,c =0;
            if(accountOr.getIdProducto() == 2){
                b = accountOr.getAccountAvailable() - monto;
                accountRepository.updateAvailableAccount(accountOr.getAcountId(), b);
            }else{
                b = accountOr.getAccountTotal() - monto;
                accountRepository.updateTotalAccount(accountOr.getAcountId(), b);
            }
            c= accountDest.getAccountAvailable() + monto;
            accountRepository.updateAvailableAccount(accountDest.getAcountId(), c);
            String id = GenerateIdProcess.generate("TRA","","");
            LocalDateTime now  = LocalDateTime.now();
            transactionRepository.addTransaccion(id,accountOr.getAcountId(),now,"Pago hacia cuenta de tarjeta de credito " + accountDest.getAcountId(),monto*-1);
            transactionRepository.addTransaccion(GenerateIdProcess.generate("TRA","","")
                    ,accountDest.getAcountId(), LocalDateTime.now(),"Pago desde cuenta " + accountOr.getAcountId(),monto);
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            return new ResponseEntity<>(new MovementResponse(id, now.format(dateTimeFormatter),"Pago hacia cuenta de tarjeta de credito " + accountDest.getAcountId(), monto*-1), HttpStatus.OK);
        }catch(Exception e){
            e.printStackTrace();
            return new ResponseEntity<>(new GeneralErrorResponse("Unexpected Error"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<?> transfer(Account accountOr, Account accountDest, double monto){
        try{
            double b=0 ,c =0;
            if(accountOr.getIdProducto() == 2){
                return new ResponseEntity<>("Unexpected Error", HttpStatus.FORBIDDEN);
            }else{
                b = accountOr.getAccountTotal() - monto;
                accountRepository.updateTotalAccount(accountOr.getAcountId(), b);
            }
            c= accountDest.getAccountAvailable() + monto;
            accountRepository.updateAvailableAccount(accountDest.getAcountId(), c);
            String id = GenerateIdProcess.generate("TRA","","");
            LocalDateTime now  = LocalDateTime.now();
            transactionRepository.addTransaccion(id,accountOr.getAcountId(), now,"Transferencia hacia cuenta " + accountDest.getAcountId(),monto*-1);
            transactionRepository.addTransaccion(GenerateIdProcess.generate("TRA","","")
                    ,accountDest.getAcountId(), LocalDateTime.now(),"Transferencia desde cuenta " + accountOr.getAcountId(),monto);
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            return new ResponseEntity<>(new MovementResponse(id, now.format(dateTimeFormatter),"Transferencia hacia cuenta " + accountDest.getAcountId(), monto*-1), HttpStatus.OK);
        }catch(Exception e){
            e.printStackTrace();
            return new ResponseEntity<>(new GeneralErrorResponse("Unexpected Error"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
