package com.loyalty.prueba.lmtest.process;

import com.loyalty.prueba.lmtest.pojo.database.Cliente;
import com.loyalty.prueba.lmtest.pojo.requests.LogInRequest;

import java.util.Base64;

public class LogInVerificator {

    public boolean verificator(Cliente client, LogInRequest request){
        Sha512Process sha512Process = new Sha512Process();

        String hash = Base64.getEncoder().encodeToString(request.getUserId().getBytes()) +
                Base64.getEncoder().encodeToString(request.getPassword().getBytes());

        String credentials = sha512Process.get_SHA_512_SecurePassword(hash);
        if(client.getClientePass().equals(credentials)){
            return true;
            }else{
            return false;
        }
    }
}
