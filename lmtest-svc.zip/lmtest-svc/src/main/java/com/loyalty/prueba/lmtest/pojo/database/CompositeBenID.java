package com.loyalty.prueba.lmtest.pojo.database;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class CompositeBenID implements Serializable {
    @Column(name = "ben_id")
    private Integer benId;

    @Column(name = "ben_cli_id")
    private String clienteId;

    @Column(name = "ben_ac_ben")
    private String accountId;

    public CompositeBenID() {

    }

    public CompositeBenID(Integer benId, String clienteId, String accountId) {
        this.benId = benId;
        this.clienteId = clienteId;
        this.accountId = accountId;
    }

    public Integer getBenId() {
        return benId;
    }

    public void setBenId(Integer benId) {
        this.benId = benId;
    }

    public String getClienteId() {
        return clienteId;
    }

    public void setClienteId(String clienteId) {
        this.clienteId = clienteId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }
}
