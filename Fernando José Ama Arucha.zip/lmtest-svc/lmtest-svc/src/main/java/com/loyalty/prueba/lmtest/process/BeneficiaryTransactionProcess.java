package com.loyalty.prueba.lmtest.process;

import com.loyalty.prueba.lmtest.pojo.database.Account;
import com.loyalty.prueba.lmtest.pojo.database.Beneficiario;
import com.loyalty.prueba.lmtest.pojo.database.Cliente;
import com.loyalty.prueba.lmtest.pojo.payment.PaymentBenRequest;
import com.loyalty.prueba.lmtest.pojo.responses.GeneralErrorResponse;
import com.loyalty.prueba.lmtest.repositories.AccountRepository;
import com.loyalty.prueba.lmtest.repositories.BeneficiaryRepository;
import com.loyalty.prueba.lmtest.repositories.ClienteRepository;
import com.loyalty.prueba.lmtest.repositories.TransactionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class BeneficiaryTransactionProcess {
    private ClienteRepository clienteRepository;
    private BeneficiaryRepository beneficiaryRepository;
    private AccountRepository accountRepository;
    private TransactionRepository transactionRepository;
    private Logger log;

    public BeneficiaryTransactionProcess(ClienteRepository clienteRepository, BeneficiaryRepository beneficiaryRepository, AccountRepository accountRepository, TransactionRepository transactionRepository) {
        this.clienteRepository = clienteRepository;
        this.beneficiaryRepository = beneficiaryRepository;
        this.accountRepository = accountRepository;
        this.transactionRepository = transactionRepository;
        this.log = LoggerFactory.getLogger(this.getClass());
    }

    public ResponseEntity<?> process(PaymentBenRequest request, String idCliente, int transactionType){
        try {
            log.info("Payment Beneficiary Process - Searching cliente by IdCliente: " + idCliente);
            Cliente cliente = clienteRepository.verifyCredentials(idCliente);
            PaymentService paymentService = new PaymentService(accountRepository, transactionRepository);
            if (cliente == null) {//no pueden ser la misma cuenta
                log.info("Payment Beneficiary Process - Cliente not found");
                return new ResponseEntity<>(new GeneralErrorResponse("Invalid client"), HttpStatus.BAD_REQUEST);
            }
            log.info("Payment Beneficiary Process - Searching beneficiary Account");
            Beneficiario beneficiario = beneficiaryRepository.getBeneficiarioById(request.getIdBeneficiario());
            if (beneficiario == null) {
                return new ResponseEntity<>(new GeneralErrorResponse("Invalid Beneficiary ID"), HttpStatus.BAD_REQUEST);
            }
            Account accountPrin = accountRepository.getAccountByIDAndClient(request.getIdAccountPrinc(), idCliente);
            Account accountDest = accountRepository.verifyAccounByIDandType(beneficiario.getAccountId(), transactionType);
            if (accountPrin == null) {
                log.info("Payment Beneficiary Process - Accounts not found");
                return new ResponseEntity<>(new GeneralErrorResponse("There is no account where to get money"), HttpStatus.BAD_REQUEST);
            }
            if (request.getAmount() <= 0) {
                log.info("Payment Beneficiary Process - Invalid amount");
                return new ResponseEntity<>(new GeneralErrorResponse("Invalid Amount"), HttpStatus.CONFLICT);
            }
            if (accountDest == null) {
                log.info("Payment Beneficiary Process - Accounts not found");
                return new ResponseEntity<>(new GeneralErrorResponse("The beneficiary Account doesn't exist"), HttpStatus.BAD_REQUEST);
            }

            if ((request.getAmount() > accountPrin.getAccountAvailable() || accountPrin.getAccountAvailable() == 0) && accountPrin.getIdProducto() == 2) {
                log.info("Payment Beneficiary Process - Invalid amount");
                return new ResponseEntity<>(new GeneralErrorResponse("CONFLICT"), HttpStatus.CONFLICT);
            }

            if ((request.getAmount() > accountPrin.getAccountTotal() || accountPrin.getAccountTotal() <= 0) && accountPrin.getIdProducto() != 2) {
                log.info("Payment Beneficiary Process - Invalid amount");
                return new ResponseEntity<>(new GeneralErrorResponse("CONFLICT"), HttpStatus.CONFLICT);
            }

            if (accountPrin.getClienteId().equals(accountDest.getClienteId()) || beneficiaryRepository.isBeneficiary(idCliente, accountDest.getAcountId()) != 0) {
                log.info("Payment Beneficiary Process - Sending to Payment Service");
                return paymentService.amountMovement(accountPrin, accountDest, request.getAmount(), transactionType);
            } else {
                log.info("Payment Beneficiary Process - there is no relation between 2 accounts");
                return new ResponseEntity<>(new GeneralErrorResponse("Account doesn't belong to a valid Beneficiary"), HttpStatus.CONFLICT);
            }
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseEntity<>(new GeneralErrorResponse("Invalid Request"), HttpStatus.BAD_REQUEST);
        }
    }
}
