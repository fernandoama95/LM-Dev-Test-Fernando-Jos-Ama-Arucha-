package com.loyalty.prueba.lmtest.pojo.database;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;

@Entity(name = "LOGREQUEST")
public class LogRequest {
    @Id
    @Column(name="log_id")
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private String logId;

    @Column(name="log_cli_id")
    private String clienteId;

    @ManyToOne(cascade = CascadeType.ALL  )
    @JoinColumn(name = "log_cli_id", referencedColumnName = "cli_id", insertable = false, updatable = false)
    @JsonIgnore
    private Cliente clienteLogRequest;

    public String getLogId() {
        return logId;
    }

    public void setLogId(String logId) {
        this.logId = logId;
    }

    public String getClienteId() {
        return clienteId;
    }

    public void setClienteId(String clienteId) {
        this.clienteId = clienteId;
    }

    public Cliente getClienteLogRequest() {
        return clienteLogRequest;
    }

    public void setClienteLogRequest(Cliente clienteLogRequest) {
        this.clienteLogRequest = clienteLogRequest;
    }
}
