package com.loyalty.prueba.lmtest.process;

import com.loyalty.prueba.lmtest.pojo.database.Transaccion;
import com.loyalty.prueba.lmtest.pojo.responses.GeneralErrorResponse;
import com.loyalty.prueba.lmtest.pojo.responses.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class TransactionLoaderProcess {
    private Logger log;
    public TransactionLoaderProcess() {
        this.log = LoggerFactory.getLogger(this.getClass());
    }
    public List<Transaction> loader(List<Transaccion> tranDb){
        try {
            List<Transaction> transactions = new ArrayList<>();
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            log.info("getTransactions Process - Transaction: " + transactions.size());
            for (Transaccion tra : tranDb) {
                Transaction transaction = new Transaction();
                transaction.setId(tra.getTransactionId());
                transaction.setAmount(tra.getTransactionAmount());
                transaction.setDescription(tra.getTransactionDesc());
                transaction.setDate(tra.getTransactionDate().format(dateTimeFormatter));
                transactions.add(transaction);
            }
            return transactions;
        }catch (Exception e){
            e.printStackTrace();
            log.error(e.getMessage());
            return null;

        }
    }
}
