package com.loyalty.prueba.lmtest.process;

import com.loyalty.prueba.lmtest.pojo.requests.BeneficiaryRequest;
import com.loyalty.prueba.lmtest.pojo.responses.BeneficiarioResponse;
import com.loyalty.prueba.lmtest.pojo.responses.GeneralErrorResponse;
import com.loyalty.prueba.lmtest.repositories.AccountRepository;
import com.loyalty.prueba.lmtest.repositories.BeneficiaryRepository;
import com.loyalty.prueba.lmtest.repositories.ClienteRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class AddBeneficiaryProcess {
    private ClienteRepository clienteRepository;
    private BeneficiaryRepository beneficiaryRepository;
    private AccountRepository accountRepository;
    private Logger log;
    public AddBeneficiaryProcess(ClienteRepository clienteRepository, BeneficiaryRepository beneficiaryRepository, AccountRepository accountRepository) {
        this.clienteRepository = clienteRepository;
        this.beneficiaryRepository = beneficiaryRepository;
        this.accountRepository = accountRepository;
        this.log = LoggerFactory.getLogger(this.getClass());
    }

    public ResponseEntity<?> addBeneficiary(BeneficiaryRequest request, String clienteId){
        try {
            BeneficiaryValidationProcess beneficiaryValidationProcess = new BeneficiaryValidationProcess(clienteRepository, beneficiaryRepository, accountRepository);
            int validator = beneficiaryValidationProcess.beneficiaryValidator(request, clienteId);

            if (validator == 1) {
                return new ResponseEntity<>(new GeneralErrorResponse("BAD_REQUEST"), HttpStatus.BAD_REQUEST);
            }
            if (validator == 2) {
                return new ResponseEntity<>(new GeneralErrorResponse("Invalid Beneficiary Account"), HttpStatus.NOT_FOUND);
            }
            if (validator == 3) {
                return new ResponseEntity<>(new GeneralErrorResponse("CONFLICT"), HttpStatus.CONFLICT);
            }
            String id = GenerateIdProcess.generate("BEN", clienteId, request.getAccountId());
            beneficiaryRepository.addBeneficiary(id, clienteId, request.getAccountId(), request.getName(), request.getApellido(), request.getEmail());
            log.info("Beneficiary created with ID: " + id);
            return new ResponseEntity<>(new BeneficiarioResponse(id, clienteId, request.getAccountId(), request.getName(), request.getApellido(), request.getEmail()), HttpStatus.CREATED);
        }catch (Exception e){
            e.printStackTrace();
            log.error(e.getMessage());
            return new ResponseEntity<>(new GeneralErrorResponse("SERVICE_UNAVAILABLE"), HttpStatus.SERVICE_UNAVAILABLE);

        }
}
}
