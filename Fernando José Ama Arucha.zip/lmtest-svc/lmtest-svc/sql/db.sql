drop schema lifebank cascade;

create schema lifebank;

create table lifebank.cliente(
	cli_id varchar(10) not null,
	cli_name varchar(50) null,
	cli_apellido varchar(50) null,
	cli_password_decrypted varchar(50),
	cli_password varchar(500),
	cli_estado_cliente varchar(2),
	cli_fecha_nac timestamptz,
	CONSTRAINT cli_pkey PRIMARY KEY (cli_id)
);

create table lifebank.logs_request(
	log_id serial not null,
	log_cli_id varchar(10),
	constraint log_pkey primary key (log_id),
	constraint log_fkey foreign key (log_cli_id) REFERENCES lifebank.cliente (cli_id)
);

create table lifebank.producto(
	prod_id int not null,
	prod_tipo varchar(2),
	CONSTRAINT prod_pkey PRIMARY KEY (prod_id)
	);

create table lifebank.account(
	ac_id varchar(10) not null,
	ac_cli_id varchar(20) not null,
	ac_duracion int DEFAULT 0,
	ac_prod_id int,
	ac_total numeric(15,2) DEFAULT 0.0,
	ac_limit numeric(15,2) DEFAULT 0.0,
	ac_available numeric(15,2) DEFAULT 0.0,
	ac_name varchar(100),
	ac_debt numeric(15,2) DEFAULT 0.0,
	ac_interes numeric(5,2) DEFAULT 0.0,
	ac_interes_amount numeric(5,2) DEFAULT 0.0,
	ac_fecha_ingreso timestamptz,
	CONSTRAINT ac_pkey PRIMARY KEY (ac_id),
	constraint ac_fkey FOREIGN KEY (ac_cli_id) REFERENCES lifebank.cliente (cli_id),
	constraint ac_prod_fkey FOREIGN KEY (ac_prod_id) REFERENCES lifebank.producto (prod_id)
);


create table lifebank.transaccion(
	tra_id varchar(25) not null,
	tra_ac_id varchar(10) not null,
	tra_date timestamptz,
	tra_description text,
	tra_amount numeric(15,2),
	CONSTRAINT tra_pkey PRIMARY KEY (tra_id),
	constraint tra_fkey FOREIGN KEY (tra_ac_id) REFERENCES lifebank.account (ac_id)
);


create table lifebank.beneficiario(
	ben_id varchar(25) not null,
	ben_cli_id varchar(10) not null, --Id cliente
	ben_ac_ben varchar(10) not null, -- Id de la cuenta del beneficiaro
	ben_nombre varchar(50),
	ben_apellido varchar(50),
	ben_email varchar(50),
	CONSTRAINT ben_pkey PRIMARY KEY (ben_id),
	constraint ben_fkey1 FOREIGN KEY (ben_cli_id) REFERENCES lifebank.cliente (cli_id),
	constraint ben_fkey2 foreign key (ben_ac_ben) references lifebank.account (ac_id)
);


INSERT INTO lifebank.producto
(prod_id, prod_tipo)
VALUES(1, 'SA'); --Saves Account
INSERT INTO lifebank.producto
(prod_id, prod_tipo)
VALUES(2, 'CA');--Credit Card Account
INSERT INTO lifebank.producto
(prod_id, prod_tipo)
VALUES(3, 'LA');--Loan Account

INSERT INTO lifebank.cliente
(cli_id, cli_name, cli_apellido, cli_password_decrypted, cli_password, cli_estado_cliente, cli_fecha_nac)
VALUES('12345678-1', 'Fernando', 'Ama','pass1234', '78973c1ed0864fbe1f2241e7c8d547829b5813191cbf2166bd912f48893097f4c9a15b030a1bea064a5fe5b1f7b699f474c504dcf7982a678890e009a8492d3c', 'A', '1995-04-13 19:30:25.000');
INSERT INTO lifebank.cliente
(cli_id, cli_name, cli_apellido, cli_password_decrypted, cli_password, cli_estado_cliente, cli_fecha_nac)
VALUES('8754321-2', 'Zedd', 'Prueba','P@zz9876', '66339dbedb8cbedd1d00570c6f3d1ea4895ed5ef88149d3d1efe4878a8423e844e9dd0c4d395f04be10fd879f897cf50b901c25b53971365005d5093484195ed', 'A', '1995-04-13 19:30:25.000');

--Loan Accounts
INSERT INTO lifebank.account
(ac_id, ac_cli_id, ac_prod_id, ac_total, ac_name, ac_debt, ac_interes, ac_interes_amount, ac_fecha_ingreso)
VALUES('AE0000007', '8754321-2', 3, 10000.00, 'Zedd Prueba', 884.27, 6.33, 130.26, current_timestamp);
INSERT INTO lifebank.account
(ac_id, ac_cli_id, ac_prod_id, ac_total, ac_name, ac_debt, ac_interes, ac_interes_amount, ac_fecha_ingreso)
VALUES('AE0000003', '12345678-1', 3, 7050.00, 'Fernando Ama', 2950.43, 5.25, 125.43, current_timestamp);
--
--Credit Card Accounts
INSERT INTO lifebank.account
(ac_id, ac_cli_id, ac_duracion, ac_prod_id, ac_limit, ac_available, ac_name, ac_interes, ac_interes_amount, ac_fecha_ingreso)
VALUES('AE0000002', '12345678-1', 18, 2, 4500.00, 3215.16, 'Fernando Ama', 5.25, 123.21, current_timestamp);
INSERT INTO lifebank.account
(ac_id, ac_cli_id, ac_duracion, ac_prod_id, ac_limit, ac_available, ac_name, ac_interes, ac_interes_amount, ac_fecha_ingreso)
VALUES('AE0000006', '8754321-2', 13, 2, 4500.00, 3515.16, 'Zedd Prueba', 5.25, 123.21, current_timestamp);
--
--Personal Accounts
INSERT INTO lifebank.account
(ac_id, ac_cli_id, ac_prod_id, ac_total, ac_name,ac_fecha_ingreso)
VALUES('AE0000004', '8754321-2', 1, 12345.74, 'Zedd Prueba', current_timestamp);
INSERT INTO lifebank.account
(ac_id, ac_cli_id, ac_prod_id, ac_total, ac_name,ac_fecha_ingreso)
VALUES('AE0000001', '12345678-1', 1, 10695.62, 'Fernando Ama',current_timestamp);
INSERT INTO lifebank.account
(ac_id, ac_cli_id, ac_prod_id, ac_total, ac_name,ac_fecha_ingreso)
VALUES('AE0000005', '12345678-1', 1, 5000.00, 'Fernando Ama', current_timestamp);
