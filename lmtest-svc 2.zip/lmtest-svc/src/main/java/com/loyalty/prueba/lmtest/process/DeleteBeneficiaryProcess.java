package com.loyalty.prueba.lmtest.process;

import com.loyalty.prueba.lmtest.pojo.database.Account;
import com.loyalty.prueba.lmtest.pojo.database.Beneficiario;
import com.loyalty.prueba.lmtest.pojo.database.Cliente;
import com.loyalty.prueba.lmtest.pojo.database.CompositeBenID;
import com.loyalty.prueba.lmtest.pojo.requests.BeneficiaryRequest;
import com.loyalty.prueba.lmtest.repositories.AccountRepository;
import com.loyalty.prueba.lmtest.repositories.BeneficiaryRepository;
import com.loyalty.prueba.lmtest.repositories.ClienteRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class DeleteBeneficiaryProcess {
    private ClienteRepository clienteRepository;
    private BeneficiaryRepository beneficiaryRepository;
    private AccountRepository accountRepository;

    public DeleteBeneficiaryProcess(ClienteRepository clienteRepository, BeneficiaryRepository beneficiaryRepository, AccountRepository accountRepository) {
        this.clienteRepository = clienteRepository;
        this.beneficiaryRepository = beneficiaryRepository;
        this.accountRepository = accountRepository;
    }

    public ResponseEntity<?> deleteBeneficiary(BeneficiaryRequest request, String clienteId, int beneficiaryID){
        BeneficiaryValidationProcess beneficiaryValidationProcess = new BeneficiaryValidationProcess(clienteRepository,beneficiaryRepository,accountRepository);
        int validator = beneficiaryValidationProcess.beneficiaryValidator(request,clienteId);

        if(validator == 0) {
            return new ResponseEntity<>(null, HttpStatus.CONFLICT);
        }
        if(validator == 1){
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
        if(validator == 2){
            return new ResponseEntity<>("Invalid Beneficiary Account", HttpStatus.NOT_FOUND);
        }
        beneficiaryRepository.deleteBeneficiary(clienteId, beneficiaryID,request.getAccountId());
        return new ResponseEntity<>("Exito", HttpStatus.NO_CONTENT);

    }
}
