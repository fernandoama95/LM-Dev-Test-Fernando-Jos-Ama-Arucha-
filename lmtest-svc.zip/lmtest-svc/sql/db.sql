drop schema lifebank cascade;

create schema lifebank;

create table lifebank.cliente(
	cli_id varchar(10) not null,
	cli_name varchar(50) null,
	cli_apellido varchar(50) null,
	cli_password varchar(500),
	cli_estado_cliente varchar(2),
	cli_fecha_nac timestamptz,
	CONSTRAINT cli_pkey PRIMARY KEY (cli_id)
);

create table lifebank.logs_request(
	log_id serial not null,
	log_cli_id varchar(10),
	constraint log_pkey primary key (log_id),
	constraint log_fkey foreign key (log_cli_id) REFERENCES lifebank.cliente (cli_id)
);

create table lifebank.producto(
	prod_id int not null,
	prod_tipo varchar(2),
	CONSTRAINT prod_pkey PRIMARY KEY (prod_id)
	);

create table lifebank.account(
	ac_id varchar(10) not null,
	ac_cli_id varchar(20) not null,
	ac_duracion int,
	ac_prod_id int,
	ac_total numeric(10,2),
	ac_limit numeric(10,2),
	ac_available numeric(10,2),
	ac_name varchar(100),
	ac_debt numeric(10,2),
	ac_interes numeric(5,2),
	ac_interes_amount numeric(5,2),
	ac_fecha_ingreso timestamptz,
	CONSTRAINT ac_pkey PRIMARY KEY (ac_id),
	constraint ac_fkey FOREIGN KEY (ac_cli_id) REFERENCES lifebank.cliente (cli_id),
	constraint ac_prod_fkey FOREIGN KEY (ac_prod_id) REFERENCES lifebank.producto (prod_id)
);

create table lifebank.transaccion(
	tra_id serial not null,
	tra_ac_id varchar(10) not null,
	tra_date timestamptz,
	tra_description text,
	tra_amount numeric(5,2),
	CONSTRAINT tra_pkey PRIMARY KEY (tra_id),
	constraint tra_fkey FOREIGN KEY (tra_ac_id) REFERENCES lifebank.account (ac_id)
);


create table lifebank.beneficiario(
	ben_id serial not null,
	ben_cli_id varchar(10) not null, --Id cliente
	ben_ac_ben varchar(10) not null, -- Id de la cuenta del beneficiaro
	ben_nombre varchar(50),
	ben_apellido varchar(50),
	ben_email varchar(50),
	CONSTRAINT ben_pkey PRIMARY KEY (ben_id,ben_cli_id, ben_ac_ben),
	constraint ben_fkey1 FOREIGN KEY (ben_cli_id) REFERENCES lifebank.cliente (cli_id),
	constraint ben_fkey2 foreign key (ben_ac_ben) references lifebank.account (ac_id)
);