package com.loyalty.prueba.lmtest.process;

import com.loyalty.prueba.lmtest.pojo.database.Account;
import com.loyalty.prueba.lmtest.pojo.database.Cliente;
import com.loyalty.prueba.lmtest.pojo.requests.BeneficiaryRequest;
import com.loyalty.prueba.lmtest.repositories.AccountRepository;
import com.loyalty.prueba.lmtest.repositories.BeneficiaryRepository;
import com.loyalty.prueba.lmtest.repositories.ClienteRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class AddBeneficiaryProcess {
    private ClienteRepository clienteRepository;
    private BeneficiaryRepository beneficiaryRepository;
    private AccountRepository accountRepository;
    public AddBeneficiaryProcess(ClienteRepository clienteRepository, BeneficiaryRepository beneficiaryRepository, AccountRepository accountRepository) {
        this.clienteRepository = clienteRepository;
        this.beneficiaryRepository = beneficiaryRepository;
        this.accountRepository = accountRepository;
    }

    public ResponseEntity<?> addBeneficiary(BeneficiaryRequest request, String clienteId){
        Cliente cliente = clienteRepository.verifyCredentials(clienteId);
        if(cliente!= null){
            Account account = accountRepository.getBeneficiaryAccount(request.getAccountId(),cliente.getClienteId(), request.getTipoCuenta());
            if(account != null){
                int isBeneficiary = beneficiaryRepository.isBeneficiary(cliente.getClienteId(), account.getAcountId());
                if(isBeneficiary >0){
                    return new ResponseEntity<>("Invalid Beneficiary Account", HttpStatus.CONFLICT);
                }
                beneficiaryRepository.addBeneficiary(cliente.getClienteId(), account.getAcountId(), request.getName(),request.getName(), request.getEmail());
                return new ResponseEntity<>(null, HttpStatus.CREATED);
            }else{
                return new ResponseEntity<>("Invalid Beneficiary Account", HttpStatus.NOT_FOUND);
            }
        }
        return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
    }
}
