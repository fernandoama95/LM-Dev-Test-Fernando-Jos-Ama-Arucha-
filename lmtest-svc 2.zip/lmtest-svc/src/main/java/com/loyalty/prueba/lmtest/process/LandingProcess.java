package com.loyalty.prueba.lmtest.process;

import com.loyalty.prueba.lmtest.parser.LandingParser;
import com.loyalty.prueba.lmtest.pojo.database.Cliente;
import com.loyalty.prueba.lmtest.pojo.responses.Accounts;
import com.loyalty.prueba.lmtest.pojo.responses.AccountsResponse;
import com.loyalty.prueba.lmtest.repositories.AccountRepository;
import com.loyalty.prueba.lmtest.repositories.ClienteRepository;


public class LandingProcess {
    private AccountRepository accountRepository;
    private ClienteRepository clienteRepository;

    public LandingProcess(AccountRepository accountRepository, ClienteRepository clienteRepository) {
        this.accountRepository = accountRepository;
        this.clienteRepository = clienteRepository;
    }

    public AccountsResponse process(String clientId){
        LandingParser landingParser = new LandingParser(accountRepository);
        AccountsResponse response = new AccountsResponse();
        Accounts accounts = new Accounts();
        Cliente client = clienteRepository.verifyCredentials(clientId);
        if(client!= null){
            accounts = landingParser.parser(client.getClienteId());
        }
        response.setAccounts(accounts);
        return response;
    }
}
