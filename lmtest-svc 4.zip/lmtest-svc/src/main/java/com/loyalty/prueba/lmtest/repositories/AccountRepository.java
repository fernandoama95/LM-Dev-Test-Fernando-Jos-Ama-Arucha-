package com.loyalty.prueba.lmtest.repositories;

import com.loyalty.prueba.lmtest.pojo.database.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

public interface AccountRepository extends JpaRepository<Account,String> {

    @Query(value = "SELECT * FROM LIFEBANK.ACCOUNT WHERE AC_CLI_ID = (:clientID)", nativeQuery = true)
    List<Account> getAccountsByClient(@Param("clientID") String clientID);

    @Query(value = "SELECT * FROM LIFEBANK.ACCOUNT WHERE AC_ID = (:accountID) and AC_CLI_ID = (:clienteID) and ac_prod_id = (:tipoProd)", nativeQuery = true)
    Account getAccountByIDAndClientAndType(@Param("accountID") String accountID, @Param("clienteID") String clienteID, @Param("tipoProd") int tipoProd);

    @Query(value = "SELECT * FROM LIFEBANK.ACCOUNT WHERE AC_ID = (:accountID) and AC_CLI_ID = (:clienteID)", nativeQuery = true)
    Account getAccountByIDAndClient(@Param("accountID") String accountID, @Param("clienteID") String clienteID);

    @Query(value = "SELECT * FROM LIFEBANK.ACCOUNT WHERE AC_ID = (:accountID) and AC_CLI_ID != (:clienteID) and AC_PROD_ID = :tipoCuenta", nativeQuery = true)
    Account getBeneficiaryAccount(@Param("accountID") String accountID, @Param("clienteID") String clienteID, @Param("tipoCuenta") int tipoCuenta);

    @Query(value = "SELECT * FROM LIFEBANK.ACCOUNT WHERE AC_ID = (:accountID) and AC_PROD_ID = :tipoCuenta", nativeQuery = true)
    Account verifyAccounByIDandType(@Param("accountID") String accountID, @Param("tipoCuenta") int tipoCuenta);

    /*ac_total numeric(10,2) NULL,
	ac_available numeric(10,2) NULL,*/
    @Modifying(clearAutomatically = true)
    @Query(value="update lifebank.ACCOUNT set ac_total = :amount where ac_id = (:accountID)",nativeQuery = true)
    @Transactional(rollbackFor = {Exception.class})
    int updateTotalAccount(@Param("accountID") String accountID, @Param("amount") double amount);

    @Modifying(clearAutomatically = true)
    @Query(value="update lifebank.ACCOUNT set ac_available   = :amount where ac_id = (:accountID)",nativeQuery = true)
    @Transactional(rollbackFor = {Exception.class})
    int updateAvailableAccount(@Param("accountID") String accountID, @Param("amount") double amount);

    @Modifying(clearAutomatically = true)
    @Query(value="update lifebank.ACCOUNT set ac_debt = :amount where ac_id = (:accountID)",nativeQuery = true)
    @Transactional(rollbackFor = {Exception.class})
    int updateDebtAccount(@Param("accountID") String accountID, @Param("amount") double amount);

}
