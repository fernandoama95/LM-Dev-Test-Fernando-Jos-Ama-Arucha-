package com.loyalty.prueba.lmtest.handler;

import com.loyalty.prueba.lmtest.pojo.payment.PaymentBenRequest;
import com.loyalty.prueba.lmtest.pojo.payment.PaymentRequest;
import com.loyalty.prueba.lmtest.pojo.requests.BeneficiaryRequest;
import com.loyalty.prueba.lmtest.pojo.requests.UpdateBeneficiaryRequest;
import com.loyalty.prueba.lmtest.repositories.BeneficiaryRepository;

public class ValidatorHandler {
    public ValidatorHandler() {
    }

    public static boolean validatePaymentRequest(PaymentRequest request, String authorization){
        if(request == null || authorization == null){
            return  false;
        }
        if(request.getIdAccountDest() == null || request.getIdAccountPrinc() == null || request.getAmount() == null){
            return false;
        }
        return true;
    }

    public static boolean validatePaymentBenRequest(PaymentBenRequest request, String authorization){
        if(request == null || authorization == null){
            return  false;
        }
        if(request.getIdBeneficiario() == null || request.getIdAccountPrinc() == null || request.getAmount() == null){
            return false;
        }
        return true;
    }

    public static boolean validateBeneficiaryRequest(BeneficiaryRequest request, String authorization){
        if(request == null || authorization == null){
            return  false;
        }
        if(request.getAccountId() == null || request.getName() == null || request.getEmail() == null || request.getApellido() == null || request.getTipoCuenta() == null){
            return false;
        }
        return true;
    }

    public static boolean validateUpdateBeneficiaryRequest(UpdateBeneficiaryRequest request, String authorization){
        if(request == null || authorization == null){
            return  false;
        }
        if( request.getName() == null || request.getEmail() == null || request.getApellido() == null){
            return false;
        }
        return true;
    }


}
