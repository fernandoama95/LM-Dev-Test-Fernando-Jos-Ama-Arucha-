package com.loyalty.prueba.lmtest.process;

import com.loyalty.prueba.lmtest.pojo.database.Account;
import com.loyalty.prueba.lmtest.repositories.AccountRepository;
import com.loyalty.prueba.lmtest.repositories.TransactionRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;


public class PaymentService {
    private AccountRepository accountRepository;
    private TransactionRepository transactionRepository;


    public PaymentService(AccountRepository accountRepository, TransactionRepository transactionRepository) {
        this.accountRepository = accountRepository;
        this.transactionRepository = transactionRepository;
    }


    public ResponseEntity<?> amountMovement(Account accountOr, Account accountDest, double monto, int process) {
        switch (process) {
            case 1:
                return new ResponseEntity<>("Unexpected Error", HttpStatus.SERVICE_UNAVAILABLE);
            case 2:
                return new ResponseEntity<>("Unexpected Error", HttpStatus.SERVICE_UNAVAILABLE);
            case 3:
                return new ResponseEntity<>("Unexpected Error", HttpStatus.SERVICE_UNAVAILABLE);
            default:
                return new ResponseEntity<>("Unexpected Error", HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

    public ResponseEntity<?> payLoan(Account accountOr, Account accountDest, double monto){
        try{
            double a= 0,b=0 ,c =0 ,d=0;
            if(accountOr.getIdProducto() == 2){
                b = accountOr.getAccountAvailable() - monto;
                accountRepository.updateAvailableAccount(accountOr.getAcountId(), b);
            }else{
                b = accountOr.getAccountTotal() - monto;
                accountRepository.updateTotalAccount(accountOr.getAcountId(), b);
            }
            c= accountDest.getAccountDebt() - monto;
            accountRepository.updateDebtAccount(accountDest.getAcountId(), c);
            return new ResponseEntity<>("Unexpected Error", HttpStatus.INTERNAL_SERVER_ERROR);
        }catch(Exception e){
            e.printStackTrace();
            return new ResponseEntity<>("Unexpected Error", HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }
}
