package com.loyalty.prueba.lmtest.process;

import com.loyalty.prueba.lmtest.pojo.database.Account;
import com.loyalty.prueba.lmtest.pojo.database.Cliente;
import com.loyalty.prueba.lmtest.pojo.payment.PaymentRequest;
import com.loyalty.prueba.lmtest.pojo.responses.GeneralErrorResponse;
import com.loyalty.prueba.lmtest.repositories.AccountRepository;
import com.loyalty.prueba.lmtest.repositories.BeneficiaryRepository;
import com.loyalty.prueba.lmtest.repositories.ClienteRepository;
import com.loyalty.prueba.lmtest.repositories.TransactionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class PaymentProcess {
    private ClienteRepository clienteRepository;
    private BeneficiaryRepository beneficiaryRepository;
    private AccountRepository accountRepository;
    private TransactionRepository transactionRepository;
    private Logger log;


    public PaymentProcess(ClienteRepository clienteRepository, BeneficiaryRepository beneficiaryRepository, AccountRepository accountRepository, TransactionRepository transactionRepository) {
        this.clienteRepository = clienteRepository;
        this.beneficiaryRepository = beneficiaryRepository;
        this.accountRepository = accountRepository;
        this.transactionRepository = transactionRepository;
        this.log = LoggerFactory.getLogger(this.getClass());
    }

    public ResponseEntity<?> process(PaymentRequest request, String idCliente, int transactionType){
        try{
        log.info("Payment Process - Searching cliente by IdCliente: " + idCliente);
        Cliente cliente =  clienteRepository.verifyCredentials(idCliente);
        PaymentService paymentService = new PaymentService(accountRepository,transactionRepository);
        if(cliente == null || request.getIdAccountPrinc().equals(request.getIdAccountDest())){//no pueden ser la misma cuenta
            log.info("Payment Process - Cliente not found");
            return new ResponseEntity<>(new GeneralErrorResponse("Invalid client"), HttpStatus.BAD_REQUEST);
        }
        log.info("Payment Process - Searching accounts");
        Account accountPrin = accountRepository.getAccountByIDAndClient(request.getIdAccountPrinc(),idCliente);
        Account accountDest = accountRepository.verifyAccounByIDandType(request.getIdAccountDest(),transactionType);
        if(accountPrin == null || accountDest == null){
            log.info("Payment Process - Accounts not found");
            return new ResponseEntity<>(new GeneralErrorResponse("Invalid Account"), HttpStatus.BAD_REQUEST);
        }
        if(request.getAmount() <=0){
            log.info("Payment Process - Invalid amount");
            return new ResponseEntity<>(new GeneralErrorResponse("Invalid Amount"), HttpStatus.CONFLICT);
        }

        if ((request.getAmount() > accountPrin.getAccountTotal() || accountPrin.getAccountTotal() <= 0) && accountPrin.getIdProducto()!=2){
            log.info("Payment Process - Invalid amount");
            return new ResponseEntity<>(new GeneralErrorResponse("CONFLICT"),HttpStatus.CONFLICT);
        }

        if ((request.getAmount() > accountPrin.getAccountAvailable() || accountPrin.getAccountAvailable() == 0) && accountPrin.getIdProducto()==2){
            log.info("Payment Process - Invalid amount");
            return new ResponseEntity<>(new GeneralErrorResponse("CONFLICT"),HttpStatus.CONFLICT);
        }

        if(accountPrin.getClienteId().equals(accountDest.getClienteId()) || beneficiaryRepository.isBeneficiary(idCliente,accountDest.getAcountId()) != 0){
            // transferencia entre cuentas propias ó hacia un beneficiario
            log.info("Payment Process - Trying to make money movements");
            return paymentService.amountMovement(accountPrin,accountDest,request.getAmount(),transactionType);
        }else{
            return new ResponseEntity<>(new GeneralErrorResponse("Account doesn't belong to a valid Beneficiary"), HttpStatus.CONFLICT);
        }
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseEntity<>(new GeneralErrorResponse("Invalid Request"), HttpStatus.BAD_REQUEST);
        }
    }
}
