package com.loyalty.prueba.lmtest.controller;

import com.loyalty.prueba.lmtest.pojo.payment.PaymentRequest;
import com.loyalty.prueba.lmtest.pojo.requests.BeneficiaryRequest;
import com.loyalty.prueba.lmtest.pojo.requests.LogInRequest;
import com.loyalty.prueba.lmtest.pojo.responses.AccountsResponse;
import com.loyalty.prueba.lmtest.pojo.responses.JWTResponse;
import com.loyalty.prueba.lmtest.process.*;
import com.loyalty.prueba.lmtest.repositories.*;
import com.loyalty.prueba.lmtest.utility.JWT;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/test")
public class Controller {
    @Autowired
    private Environment env;
    @Autowired
    private ClienteRepository clienteRepository;
    @Autowired
    private LogRequestRepository logRequestRepository;
    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private TransactionRepository transactionRepository;
    @Autowired
    private BeneficiaryRepository beneficiaryRepository;
    private static  int TRANSEFERENCIA = 1;
    private static  int PAGO_CC = 2;
    private static  int PAGO_LOAN = 3;



    @GetMapping("/get-client-info/{idCliente}")
    public ResponseEntity<?> getClientInfo(@PathVariable String idCliente, @RequestHeader String authorization){
        LandingProcess landingProcess = new LandingProcess(accountRepository, clienteRepository);
        JWTHandler jwtHandler = new JWTHandler();
        switch (jwtHandler.validateJWT(authorization,env.getProperty("ipAddress"))){
            case 0:
                AccountsResponse response = landingProcess.process(idCliente);
                if(response != null){
                    return new ResponseEntity<>(response,HttpStatus.OK);
                }else{
                    return new ResponseEntity<>(null,HttpStatus.BAD_REQUEST);
                }
            case 1:
                return new ResponseEntity<>("Error",HttpStatus.UNAUTHORIZED);
            case 2:
                return new ResponseEntity<>("Error",HttpStatus.FORBIDDEN);
            default:
                return new ResponseEntity<>("Error",HttpStatus.SERVICE_UNAVAILABLE);
        }

    }

    @GetMapping("/transaction/{idAccount}")
    public ResponseEntity<?> getTransactions(@PathVariable String idAccount,@RequestParam String startDate, @RequestParam String endDate, @RequestHeader String authorization){
        TransactionProcess landingProcess = new TransactionProcess(accountRepository, transactionRepository);
        JWTHandler jwtHandler = new JWTHandler();
        switch (jwtHandler.validateJWT(authorization,env.getProperty("ipAddress"))){
            case 0:
                return landingProcess.process(idAccount,startDate,endDate);
            case 1:
                return new ResponseEntity<>("Error",HttpStatus.UNAUTHORIZED);
            case 2:
                return new ResponseEntity<>("Error",HttpStatus.FORBIDDEN);
            default:
                return new ResponseEntity<>("Error",HttpStatus.SERVICE_UNAVAILABLE);
        }

        }

    @PostMapping("/log-in")
    public ResponseEntity<?> logIn(@RequestBody LogInRequest request){
        VerifyProcess verifyProcess = new VerifyProcess(clienteRepository, logRequestRepository);
        int response = verifyProcess.process(request);
        JWTHandler jwtHandler = new JWTHandler();
        switch(response){
            case 1://loggeo fallido
                return new ResponseEntity<>("Credenciales incorrectas", HttpStatus.UNAUTHORIZED);
            case 2://cuenta bloqueada
                return new ResponseEntity<>("User Blocked", HttpStatus.BAD_REQUEST);
            case 0://exito
                JWTResponse jwtResponse = new JWTResponse();
                jwtResponse.setTkn(jwtHandler.getEncrypt(request.getUserId(),env.getProperty("ipAddress")));
                return new ResponseEntity<>(jwtResponse, HttpStatus.OK);
            default://unexpected error
                return new ResponseEntity<>("Unknown Error", HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

    @PostMapping("/transfer")
    public ResponseEntity<?> transfer(@RequestBody PaymentRequest request, @RequestHeader String authorization){
        PaymentProcess paymentProcess = new PaymentProcess(clienteRepository,beneficiaryRepository,accountRepository,transactionRepository);
        JWTHandler jwtHandler = new JWTHandler();
        switch (jwtHandler.validateJWT(authorization,env.getProperty("ipAddress"))){
            case 0:
                return paymentProcess.process(request,jwtHandler.getClienteID(),TRANSEFERENCIA);
            case 1:
                return new ResponseEntity<>("Error",HttpStatus.UNAUTHORIZED);
            case 2:
                return new ResponseEntity<>("Error",HttpStatus.FORBIDDEN);
            default:
                return new ResponseEntity<>("Error",HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

    @PostMapping("/pay/loan")
    public ResponseEntity<?> loanPayment(@RequestBody PaymentRequest request, @RequestHeader String authorization){
        PaymentProcess paymentProcess = new PaymentProcess(clienteRepository,beneficiaryRepository,accountRepository,transactionRepository);
        JWTHandler jwtHandler = new JWTHandler();
        switch (jwtHandler.validateJWT(authorization,env.getProperty("ipAddress"))){
            case 1:
                return new ResponseEntity<>("Error",HttpStatus.UNAUTHORIZED);
            case 0:
                return paymentProcess.process(request,jwtHandler.getClienteID(),PAGO_LOAN);
            case 2:
                return new ResponseEntity<>("Error",HttpStatus.FORBIDDEN);
            default:
                return new ResponseEntity<>("Error",HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

    @PostMapping("/pay/card")
    public ResponseEntity<?> creditCardPayment(@RequestBody PaymentRequest request, @RequestHeader String authorization){
        PaymentProcess paymentProcess = new PaymentProcess(clienteRepository,beneficiaryRepository,accountRepository,transactionRepository);
        JWTHandler jwtHandler = new JWTHandler();
        switch (jwtHandler.validateJWT(authorization,env.getProperty("ipAddress"))){

            case 1:
                return new ResponseEntity<>("Error",HttpStatus.UNAUTHORIZED);
            case 2:
                return new ResponseEntity<>("Error",HttpStatus.FORBIDDEN);
            case 0:
                return paymentProcess.process(request,jwtHandler.getClienteID(),PAGO_CC);
            default:
                return new ResponseEntity<>("Error",HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

    @PostMapping("/beneficiary/add")
    public ResponseEntity<?> addBeneficiario(@RequestBody BeneficiaryRequest request, @RequestHeader String authorization){
        AddBeneficiaryProcess addBeneficiaryProcess = new AddBeneficiaryProcess(clienteRepository,beneficiaryRepository,accountRepository);
        JWTHandler jwtHandler = new JWTHandler();
        switch (jwtHandler.validateJWT(authorization,env.getProperty("ipAddress"))){
            case 0:
                return  addBeneficiaryProcess.addBeneficiary(request, jwtHandler.getClienteID());
            case 1:
                return new ResponseEntity<>("Error",HttpStatus.UNAUTHORIZED);
            case 2:
                return new ResponseEntity<>("Error",HttpStatus.FORBIDDEN);
            default:
                return new ResponseEntity<>("Error",HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

    @PatchMapping("/beneficiary/edit/{beneficiaryID}")
    public ResponseEntity<?> editBeneficiario(@PathVariable int beneficiaryID, @RequestBody BeneficiaryRequest request, @RequestHeader String authorization){
        EditBeneficiaryProcess editBeneficiaryProcess = new EditBeneficiaryProcess(clienteRepository,beneficiaryRepository,accountRepository);
        JWTHandler jwtHandler = new JWTHandler();
        switch (jwtHandler.validateJWT(authorization,env.getProperty("ipAddress"))){
            case 0:
                return  editBeneficiaryProcess.editBeneficiary(request,jwtHandler.getClienteID(),beneficiaryID);
            case 1:
                return new ResponseEntity<>("Error",HttpStatus.UNAUTHORIZED);
            case 2:
                return new ResponseEntity<>("Error",HttpStatus.FORBIDDEN);
            default:
                return new ResponseEntity<>("Error",HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

    @DeleteMapping("/beneficiary/delete/{beneficiaryID}")
    public ResponseEntity<?> deleteBeneficiary(@PathVariable int beneficiaryID,@RequestBody BeneficiaryRequest request, @RequestHeader String authorization){
        DeleteBeneficiaryProcess deleteBeneficiaryProcess = new DeleteBeneficiaryProcess(clienteRepository,beneficiaryRepository,accountRepository);
        JWTHandler jwtHandler = new JWTHandler();
        switch (jwtHandler.validateJWT(authorization,env.getProperty("ipAddress"))){
            case 0:
                return  deleteBeneficiaryProcess.deleteBeneficiary(request,jwtHandler.getClienteID(),beneficiaryID);
            case 1:
                return new ResponseEntity<>("Error",HttpStatus.UNAUTHORIZED);
            case 2:
                return new ResponseEntity<>("Error",HttpStatus.FORBIDDEN);
            default:
                return new ResponseEntity<>("Error",HttpStatus.SERVICE_UNAVAILABLE);
        }
    }
}
